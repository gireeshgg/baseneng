package employee;
import java.util.*;
class Employee{
	private String Mid;
	private String Name;
	private String Designation;
	Employee(){};
	public Employee(String mid, String name, String designation) {
		super();
		Mid = mid;
		Name = name;
		Designation = designation;
	}
	public String getMid() {
		return Mid;
	}
	public String getName() {
		return Name;
	}

	void show() {
		System.out.print(Mid+" ");
		System.out.print(Name+" ");
		System.out.println(Designation+" ");
	}
	
}












public class EmloyeeClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		// TODO Auto-generated method stub
		Employee []e=new Employee[5];
		e[0]=new Employee("M104","ranjan","Engineer");
		e[1]=new Employee("M105","sajan","Engineer");
		e[2]=new Employee("M102","janvi","Engineer");
		e[3]=new Employee("M101","arthi","Engineer");
		e[4]=new Employee("M103","mukheh","Engineer");
		 
		for(int i=0;i<5;i++) {                                             //bubble sort
			for(int j=i+1;j<5;j++) {
				if(stringCompare(e[i].getName(),e[j].getName())>0) {
					Employee temp=new Employee();
					temp= e[i];
					 e[i]=e[j];
					 e[j]=temp;
				}
			}
			}
		for(int i=0;i<5;i++) {
			e[i].show();
		}
		
		System.out.println("Enter Mid to search");
        String word=sc.next();
        boolean flag=true;
		for(int i=0;i<5;i++) {							//linear search
			String temp1=e[i].getMid();
			if(Equal(temp1,word)) {
				e[i].show();
				flag=false;
			}
		}
		if(flag)
		System.out.println("MID Not Found");
		
    sc.close();
	}

	
	
	
	
	
	
	
	
	
	
	
	//functions-----------------------------------------------------------------------------------------------------
	static int  stringCompare(String s,String s1) {
		  int length=s.length();
		  if(s.length()<s1.length()) {
			  length=s.length();
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return -1;
		  }
		  else if(s.length()>s1.length()){
			  length=s1.length();
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return 1;
		  }else if(s.length()==s1.length()) {
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return 0;
		  }
		  return 0;
	  }
 
	 
	//equal function----------------------------------------------------------------------------  
	  static boolean Equal(String str,String str1) {             //equal function
			boolean flag=true;
			if(str.length()!=str1.length()) {
				return false;
			}
			for(int x=0;x<str.length();x++) {
				if(str.charAt(x)!=str1.charAt(x)) {
					flag=false;
					break;
				}
			}
			return flag;
		}
	  


}
