package matrixRotation;
import java.util.*;
public class MatrixRotation {
 static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter  Diamension");
	int n=sc.nextInt();
	int [][]a=new int[n][n];
	System.out.println("Enter Elements");

	 for(int i=0;i<n;i++) {
	    	for(int j=0;j<n;j++) {
	    	a[i][j]=sc.nextInt();
	    	}
	 }
    int[][]b=new int[n][n];
    for(int i=0,k=0;i<n;i++,k++) {
    	for(int j=0,l=n-1;j<n;j++,l--) {
    		b[l][k]=a[i][j];
    		}
    }
	System.out.println("Rotated Matrix :");

    for(int i=0;i<n;i++) {
    	for(int j=0;j<n;j++) {
    		System.out.print(b[i][j]+" ");
    	}
    	System.out.println();
    }
    
    
    
    
	}

}
