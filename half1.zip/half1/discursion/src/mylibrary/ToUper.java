package mylibrary;
import java.util.*;
public class ToUper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		char[]up=new char[s.length()];
				for(int i=0;i<s.length();i++) {
					if(s.charAt(i)>=97 && s.charAt(i)<=127) {
					up[i]=(char)(s.charAt(i)-32);
				}
				else {
					up[i]=s.charAt(i);
				}
				}
				for(int j=0;j<up.length;j++) {
					System.out.print(up[j]);
				}

sc.close();
	}

}
