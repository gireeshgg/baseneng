package searchStringArray;
import java.util.*;

public class searchString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of word");
		int n=sc.nextInt();
		System.out.println("Enter the words");
		String []s=new String [n];
		for(int i=0;i<n;i++) {
			s[i]=sc.next();
		}
		s=sortStringArray(s);
		System.out.println("Enter String to be Searched");
		String input=sc.next();
		int c=stringBinarySearch(s,input);
		if(c==-1){
			System.out.println("Word Not Found");
		}else {
			System.out.println("Word is present :"+s[c]);
		}

		sc.close();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//functions--------------------------------------------------
	
	
	 static int  stringCompare(String s,String s1) {
		  int length=s.length();
		  if(s.length()<s1.length()) {
			  length=s.length();
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return -1;
		  }
		  else if(s.length()>s1.length()){
			  length=s1.length();
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return 1;
		  }else if(s.length()==s1.length()) {
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return 0;
		  }
		  return 0;
	  }
	  
	// linear search-----------------------------------------------------------------------------
	 static int  stringLinearSearch(String[] s,String word) {     //
		 
		 for(int i=0;i<s.length;i++) {
			if(Equal(s[i],word)) {  
			  return i;
		  }
		 }
		  return  -1;
	  }
	 //Binary Search------------------------------------------------------------------------------
	  
	  
	 static int stringBinarySearch(String[] s,String word) {
		 int low=0;
		 int high=s.length;
		 for(int i=0;i<s.length;i++) {
			int mid=(high+low)/2;
			if(stringCompare(s[mid],word)==0) {
				return mid;
			}else if(stringCompare(s[mid],word)==-1){
				low=mid+1;
			}else {
				high=mid-1;
			}
			 
		 }
		 return -1;
	 }
	 
	 
	 
	 
	 
   //bubble sort--------------------------------------------------------------------------------
	  static String[] sortStringArray(String[] s) {
		 
		  String temp=new String();
		  for(int i=0;i<s.length;i++) {
			  for(int j=i+1;j<s.length;j++) {
				  if(stringCompare(s[i],s[j])>0) {
					 temp= s[i];
					 s[i]=s[j];
					 s[j]=temp;  
				  }
			  }
			  
		  }
		    
		  return s;
	  }
	//equal function----------------------------------------------------------------------------  
	  static boolean Equal(String str,String str1) {             //equal function
			boolean flag=true;
			if(str.length()!=str1.length()) {
				return false;
			}
			for(int x=0;x<str.length();x++) {
				if(str.charAt(x)!=str1.charAt(x)) {
					flag=false;
					break;
				}
			}
			return flag;
		}
	  

}
