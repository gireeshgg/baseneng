/*  We have to calculate the percentage of marks obtained in three subjects (each out of 100)
 *  by student A and in four subjects (each out of 100) by student B.Create an abstract class
 *  'Marks' with an abstract method 'getPercentage'.It is inherited by two other classes 'A' 
 *  and 'B' each having a method with the same name which returns the percentage of the students.
 *  The constructor of student A takes the marks in three subjects as its parameters and the marks
 *  in four subjects as its parameters for student B.
 *  Create an object for each of the two classes and print the percentage of marks for both the students.
 * 
 * 
 */package marks;
import java.util.*;
class invalidMarks extends Exception{														//Custom Exception invalid marks.
	invalidMarks(String errorMsg){
	super(errorMsg);
	}
}
interface totalmarks{
	int totalMarks();
}
abstract class markss{
		abstract double getPercentage();													//abstract class markss which is extended by both students
}

	class a extends markss{
		int sub1;
		int sub2;
		int sub3;
		public a(int sub1, int sub2, int sub3) {											//student a with getPercentage method implemented 
			super();
			this.sub1 = sub1;
			this.sub2 = sub2;
			this.sub3 = sub3;
		}
		double getPercentage() {
			return ((sub1+sub2+sub3)/3);
		}
		
		
	}

	class b extends markss{
		int sub1;
		int sub2;																			//student b with getPercentage method implemented
		int sub3;
		int sub4;
		public b(int sub1, int sub2, int sub3, int sub4) {
			super();
			this.sub1 = sub1;
			this.sub2 = sub2;
			this.sub3 = sub3;
			this.sub4 = sub4;
		}
		double getPercentage() {
			return ((sub1+sub2+sub3+sub4)/4);
		}
		
	}
	
	class Marks{
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter student A marks");
			int c=0;
			int sub1=0,sub2=0,sub3=0,sub4=0;
			while(true) {
				c=0;																		//Exception handling for every input that is taken from the user. 
																							//until and unless the user input is correct code will keep on asking for the correct input throwing exception
			try {
				System.out.println("Enter student A sub1 marks");

			sub1=sc.nextInt();
			}catch(InputMismatchException e) {
				System.out.println(e);
			}
			try {
			if(sub1<0 || sub1>100) {
				throw new invalidMarks("marks sould be between 0 and 100");
			}
			c=1;
			}catch(invalidMarks e) {
				System.out.println(e);
				
			}
			if(c==1)break;
			}
			while(true) {
				c=0;
			try {				
				System.out.println("Enter student A sub2 marks");

				sub2=sc.nextInt();
				}catch(InputMismatchException e) {
					System.out.println(e);
				}
				try {
				if(sub2<0 || sub2>100) {
					throw new invalidMarks("marks sould be between 0 and 100");
				}
				c=1;
				}catch(invalidMarks e) {
					System.out.println(e);
					
				}
				if(c==1)break;
				}
				while(true) {
					c=0;
				System.out.println("Enter student A sub3 marks");

				try {
					sub3=sc.nextInt();
					}catch(InputMismatchException e) {
						System.out.println(e);
					}
					try {
					if(sub3<0 || sub3>100) {
						throw new invalidMarks("marks sould be between 0 and 100");
					}
					c=1;
					}catch(invalidMarks e) {
						System.out.println(e);
						
					}
					if(c==1)break;
				}
				
				
				
				
					a student1=new a(sub1,sub2,sub3);												//display of student a's percentage
					System.out.println(student1.getPercentage());
					System.out.println("Enter student B marks");
					
					
				while(true){
						c=0;
						try {
											System.out.println("Enter student B sub1 marks");

						sub1=sc.nextInt();
						}catch(InputMismatchException e) {
							System.out.println(e);
						}
						try {
						if(sub1<0 || sub1>100) {
							throw new invalidMarks("marks sould be between 0 and 100");
						}
						c=1;
						}catch(invalidMarks e) {
							System.out.println(e);
							
						}
						if(c==1)break;
					}
				while(true){
							c=0;
						try {				System.out.println("Enter student B sub2 marks");

						sub2=sc.nextInt();
						}catch(InputMismatchException e) {
							System.out.println(e);
						}
						try {
						if(sub2<0 || sub2>100) {
							throw new invalidMarks("marks sould be between 0 and 100");
						}
						c=1;
						}catch(invalidMarks e) {
							System.out.println(e);
						}
						if(c==1)break;
					}
				while(true){
							c=0;
						try {				System.out.println("Enter student B sub3 marks");

							sub3=sc.nextInt();
						}catch(InputMismatchException e) {
							System.out.println(e);
						}
						try {
						if(sub3<0 || sub3>100) {
							throw new invalidMarks("marks sould be between 0 and 100");
						}
						
						c=1;
						}catch(invalidMarks e) {
							System.out.println(e);	
						}
						if(c==1)break;
					}		
				while(true){
						c=0;
						try {				System.out.println("Enter student B sub4 marks");

							sub4=sc.nextInt();
						}catch(InputMismatchException e) {
							System.out.println(e);
						}
						try {
						if(sub4<0 || sub4>100) {
							throw new invalidMarks("marks sould be between 0 and 100");
						}
						c=1;
						}catch(invalidMarks e) {
							System.out.println(e);
							
						}
						
						if(c==1)break;
					}
				
				
				
						b student2=new b(sub1,sub2,sub3,sub4);
		                System.out.println(student2.getPercentage());											//display of student b's percentage
		
		
		sc.close();
		}
		
		
		
	}
	
