
package mypackages;
public class GG {
		public String Substring(int i,int j,String str) {         // Substring function
			String res=new String();
			for(int x=i;x<j;x++) {
				res=res+str.charAt(x);
			}
			return res;
		}
		
	  public boolean Equal(String str,String str1) {             //equal function
			boolean flag=true;
			for(int x=0;x<str.length();x++) {
				if(str.charAt(x)!=str1.charAt(x)) {
					flag=false;
					break;
				}
			}
			return flag;
		}
	  
	  
	  //--------------------------------------------------------------------------------------
	  
	  public int  stringCompare(String s,String s1) {
		  int length=0;
		  if(s.length()>s1.length()) {
			  length=s.length();
		  }else {
			  length=s1.length();
		  }
		  for(int x=0;x<length;x++) {
				if(s.charAt(x)>s1.charAt(x)) {
					return 1;
				}
				if(s.charAt(x)<s1.charAt(x)) {
					return -1;
				}
			}
		  return 0;
	  }
	  
	  public int  stringBinarySearch(String[] s,String word) {     //
		 
		  int temp;
		  int mid=0;
		  int high=s.length,low=0;
		  for(int i=low;i<high;i++) {
			  mid=(high+low)/2;
			  temp=stringCompare(s[mid],word);
			  if(temp>0) {
				  low=mid+1;
			  }else if(temp<0) {
				  high=mid-1;
			  }else {
				  if(temp==0) {
					  return mid;
				  }
			  }
			  
		  }
		  return  -1;
	  }
	  
	  
	  public String[] sortStringArray(String[] s) {
		 
		  String temp=new String();
		  for(int i=0;i<s.length;i++) {
			  for(int j=s.length-i;j<s.length;j++) {
				  if(stringCompare(s[j],s[j+1])>0) {
					 temp= s[j];
					 s[j]=s[j+1];
					 s[j+1]=temp;  
				  }
			  }
			  
		  }
		    
		  return s;
	  }
	  
	  
	  
	  
//class end
	}


