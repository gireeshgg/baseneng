package facingSeat;

import java.util.Scanner;
public class Seating {
	public static void main(String[] a) {
		Scanner sc= new Scanner(System.in);
		int in=sc.nextInt();
		for(int i=0;i<in;i++) {		
		int n=sc.nextInt();
		int dummy=n;
		if(n%12==0) {
			System.out.print(n-11);
		}
		else 
		if(n%12<=6){
			dummy=dummy-(n%12);
			dummy=dummy+12-(n%12);
			System.out.print(dummy+1);
		}
		
		else{
			dummy=dummy+12-(n%12);
			dummy=dummy-(n%12);
			System.out.print(dummy+1);
			
		}
		switch(n%6) {
		case 1: System.out.println(" WS");break;
		case 2: System.out.println(" MS");break;
		case 3: System.out.println(" AS");break;
		case 4: System.out.println(" AS");break;
		case 5: System.out.println(" MS");break;
		case 0: System.out.println(" WS");break;
		default:;
		}
	}
	sc.close();
	}
}

