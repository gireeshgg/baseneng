package diagonalsort;

import java.util.Scanner;

public class DiagonalSort {

	public static void main(String[] args) {
		
				Scanner sc= new Scanner(System.in);
				System.out.println("Enter Length of the array");
				int n=sc.nextInt();
				System.out.println("Enter elements of the array");
				int[][]a=new int[n][n];
					for(int i=0;i<n;i++) {
						for(int j=0;j<n;j++) {
							 a[i][j]=sc.nextInt();
						}  	
					}
				   
				   
				   int temp=0;
				    for(int z=0;z<n;z++) {
				    	for(int x=0;x<n-z-1;x++) {
				    			if(a[x][x]<a[x+1][x+1]) {
				    				temp=a[x][x];
							    	  a[x][x]=a[x+1][x+1];
							    	  a[x+1][x+1]=temp;
				    			}
				          }
				    }
				    	  
				    
				    for(int i=0;i<n;i++) {
						for(int j=0;j<n;j++) {
							 System.out.print(a[i][j]+",");
						}  	
						System.out.println();
					}
				
sc.close();
	}

}
