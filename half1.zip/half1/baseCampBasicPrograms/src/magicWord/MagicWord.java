package magicWord;
import java.util.*;
public class MagicWord {
	public static void main(String[] a) {
		Scanner sc=new Scanner(System.in);
		int T=sc.nextInt();
		
		char[] PC= {'C','G','I','O','S','Y'};
		char[] pc={'a','e','g','k','m','q'};
		for(int i=0;i<T;i++) {
			int N=sc.nextInt();
			String c=sc.next();

			for(int j=0;j<N;j++){
				System.out.print(" "+c.charAt(j));
				if(c.charAt(j)<97) {
					for(int k=0;k<PC.length-1;k++) 
					{
						if(c.charAt(j)>PC[k])
						{
							if(c.charAt(j)<PC[k+1])
							{
								if((c.charAt(j)-PC[k])>(PC[k+1]-c.charAt(j)))
								{
									System.out.print(PC[k+1]);
									

								}
								else
								{
									System.out.print(PC[k]);
									

								}
							}
						}
						if(c.charAt(j)<PC[0])
						{
							System.out.print(PC[0]);
							break;
						}
						if(c.charAt(j)>PC[5]) 
						{
							System.out.print(PC[5]);
							break;
						}
						if(c.charAt(j)==PC[k]) 
						{
							System.out.print(PC[k]);
							
						}


					}
				}
				else 
				{
					for(int k=0;k<pc.length-1;k++)
					{
						if(c.charAt(j)>pc[k])
						{
							if(c.charAt(j)<pc[k+1])
							{
								if((c.charAt(j)-pc[k])>(pc[k+1]-c.charAt(j)))
								{
									System.out.print(pc[k+1]);

								}
								else
								{
									System.out.print(pc[k]);

								}
							}
						} 
						if(c.charAt(j)<pc[0])
						{
							System.out.print(pc[0]);
							break;
						}
						if(c.charAt(j)>pc[5])
						{
							System.out.print(pc[5]);
							break;
						}

						if(c.charAt(j)==pc[k]) 
						{
							System.out.print(pc[k]);
							
						}

					}

				}

			}

		}


		sc.close();
	}
}