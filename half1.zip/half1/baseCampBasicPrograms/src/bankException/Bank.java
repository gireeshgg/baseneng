package bankException;
import java.util.*;
public class Bank {
	static account[] acc=new account[5];
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number of Accounts");
		int nAcnt=sc.nextInt();
		for(int i=0;i<nAcnt;) {															//till the enter number of accounts are created loops
			try {
				System.out.println("Account Creation: Enter\nAccount_number Name Balance");
				int acnum=0;
				try {
				  acnum=sc.nextInt();
				  
				  if(0<search(acnum,i)) {
						throw new AccountCreationException("Account Already Exists ");   // entered account already exits
					}
				}catch(InputMismatchException  e1) {
					System.out.println("Invalid Account Number");
				}
				
				
				String name=sc.next();
				if(name==null) {
					throw new AccountCreationException("Name Not Provided ");           //name not provided , can not create account 
				}
				double bal=0;
				try {
				 bal=sc.nextDouble();
				}
				catch(InputMismatchException  e1) {
					System.out.println("Enter correct ammount, ex: 1000.00 ");
				}
				
				if(bal<500) {
					throw new AccountCreationException("Balance should be greater than 500 ");
				}
				acc[i++]=new account(acnum,name,bal);	                           // if there is no exception creates a new account
			}catch(AccountCreationException e) {
				System.out.println(e+" :Account Not Ctreated");
				
			}
		}
		
		while(true) {                                                                 //Fund transfers
			sc.nextLine();
			System.out.println("Do you want to Transfer Funds:Yes (1) /No (0) ");
			if(1==sc.nextInt()) {
				int  index=0,index1=0;
				System.out.println("Enter account number of sender");
				try{
					 index=search(sc.nextInt(),nAcnt);
					 if(index==-1) {
						 throw new NullPointerException("Sender");
					 }
					System.out.println("Enter account number of reciever");
					 index1=search(sc.nextInt(),nAcnt);
					 if(index1==-1) {
						 throw new NullPointerException("Reciever");
					 }
				}catch(NullPointerException N) {
					System.out.println(N+"Account Not Found");							
				}
					System.out.println("Enter Amount:");
					double am=sc.nextDouble();
				
					transferFunds(acc[index],acc[index1],am);      			// fund transfer function
							
					sc.nextLine();                                      //ignore next line	
					
				    
				}else {
					System.out.println("Thank You...");
					break;
				}
			
		}
		
		
	
	
	sc.close();
	}
	
	
	static void transferFunds(account a,account b,double amount){
		try{
		a.withdraw(amount);
		b.deposit(amount);
		System.out.println("New balance:");
		System.out.println("\nSernder:"+a.getAccountNum()+":-"+a.getBalance()+
				"\nReciever:"+b.getAccountNum()+":-"+b.getBalance());                 // showing account log
		
		}catch(InsufficientBalanceException | AccountTransactionException e) {
			System.out.println(e);
			System.out.println(a.getAccountNum()+":-"+a.getBalance());
			System.out.println(b.getAccountNum()+":-"+b.getBalance());					// showing account log even if transfer fails

			}

	}
	
	
	
	
	static int search(int an,int NumberOfObjects) {
		int j=-1;
		for(int i=0;i<NumberOfObjects;i++) {
			if(acc[i].getAccountNum()==an) {
				return i;
			}
		}
		return j;
	}

}
