package bankException;
class BankingApplicationException extends Exception{
	
	BankingApplicationException(String a){
		super(a);
	}
}

class InsufficientBalanceException extends BankingApplicationException{
	
	InsufficientBalanceException(String a){
		super(a);
	}
}

class AccountCreationException extends BankingApplicationException{
	AccountCreationException(String a){
		super(a);
		
	}
}
class AccountTransactionException extends BankingApplicationException{
	AccountTransactionException(String a){
		super(a);
	}
}


public class account {
private int accNum;
private String cname;
private double balance;


public account(int accNum, String cname, double balance) {
	super();
	this.accNum = accNum;
	this.cname = cname;
	this.balance = balance;
}

public void deposit(double amount) throws AccountTransactionException  {
	if(amount<=0) {
		throw new AccountTransactionException("Reciever:Invalid Amount");
	}
		balance+=amount;
}

public void withdraw(double amount)throws AccountTransactionException,InsufficientBalanceException {
	if(amount<=0) {
	     throw new AccountTransactionException("Sender:Invalid Amount");
		}
		if(amount>balance) {
			 throw new InsufficientBalanceException("Insufficient balance");
		}
			balance-=amount;
				
}

public double getBalance() {
	return balance;
}
public int getAccountNum() {
	return accNum;
}

}
