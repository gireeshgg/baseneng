package minmizeCost;
import java.util.*;
public class MiniCost {
	public static void main(String[] a) {
			Scanner sc=new Scanner(System.in);
			int  n=sc.nextInt();
			int key=sc.nextInt();
			int sum=0;
			int[] ar=new int[] {1,2,3};
			for(int i=0;i<n;i++) {
				ar[i]=sc.nextInt();
				
			}
			for(int k=0;k<n;k++) {
				 if(ar[k]>0) {
				for(int j=k;j<=k+key  && j<n;j++) {
			      
					if(ar[j]<0) {
						if(ar[k]>-ar[j]) {
							ar[k]=ar[k]+ar[j];
							ar[j]=0;
							
						}else
						{
							ar[j]=ar[k]+ar[j];
							ar[k]=0;
							
						}
					}
				   }
			    }
			}
			for(int z=0;z<n;z++) {
				if(ar[z]>=0) {
					sum=sum+ar[z];
				}else {
					sum=sum+(-ar[z]);
				}
				System.out.print(" "+ar[z]);
			}
			System.out.println(" minimumSum :"+sum);
sc.close();
	}

}
