package stringcompare;

public class Stcmp {
	 static int  stringCompare(String s,String s1) {
		  int length=s.length();
		  if(s.length()<s1.length()) {
			  return -1;
			  
		  }else if(s.length()>s1.length()){
			  return 1;
		  }else {
		  for(int x=0;x<length;x++) {
				if(s.charAt(x)<s1.charAt(x)) {
					return -1;
				}
				if(s.charAt(x)>s1.charAt(x)) {
					return 1;
				}
			}
		  return 0;
		  }
		  
	  }
	 
	 
	 public static void main(String []a1) {
		 String a="aaaa";
		 String b="aaab";
		 System.out.println(stringCompare(a,b));
	 }
}
