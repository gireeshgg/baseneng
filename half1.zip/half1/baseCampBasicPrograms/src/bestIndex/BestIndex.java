package bestIndex;
import java.util.*;
public class BestIndex {
	public static void main(String[] q) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int [] a=new int[n];
	int [] sum=new int[n];
	int j=0;
	for(int x=0;x<n;x++) {
		a[x]=sc.nextInt();
	}
	for(int i=0;i<n;i++) {
		while(true) {
		sum[i]=sum[i]+a[i];
		j=j+i;
		if(j>=n)break;
	    }
	}
	
	sc.close();
  }
}
