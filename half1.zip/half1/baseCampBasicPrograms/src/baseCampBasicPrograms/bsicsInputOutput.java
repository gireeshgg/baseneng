//Ali and Helping innocent people 
package baseCampBasicPrograms;
import java.util.Scanner;
public class bsicsInputOutput {
	public static void main(String[] args){
		Scanner sc =new Scanner(System.in);
		String s=sc.next();
		int[] array=new int[7];
		char ch;
		int j=0;
		boolean b=false;
		ch=s.charAt(2);
		for(int i=0;i<9;i++){
			if(i==2 | i==6){
				continue;
			}
			array[j++]=Character.getNumericValue(s.charAt(i));
		}
		switch(ch){
		case 'A':System.out.println("invalid");break;
		case 'E':System.out.println("invalid");break;
		case 'I':System.out.println("invalid");break;
		case 'O':System.out.println("invalid");break;
		case 'U':System.out.println("invalid");break;
		case 'Y':System.out.println("invalid");break;
		default:b=true;
		}
		if(b==true){
			for(int i=0;i<6;i++){
				if((array[i]+array[i+1])%2!=0){
					System.out.println("invalid");
					b=false;
					break;
				}
				else
				{
					b=true;
				}	
			}
		}
		if(b==true){
			System.out.println("valid");
		}
				
	
		
		
		
	
sc.close();
	}
}
