/* program to demonstrate use of super in inheritance 
 * 
 */



package inheritance;

class teacher{
	 String Designation="HOD";
	 String College="SONSOCollege";
    void print() {
		System.out.println("Teacher class");
	}	
}
class MathsTeacher extends teacher{
     String topic="Algebra";
	
	void print() {
		super.print();
		System.out.println("Maths Teacher ");
	}
		
}

public class superforTeacherclass{
	
	public static void main(String[] args) {
		MathsTeacher t=new MathsTeacher();
		t.print();
		System.out.println(t.Designation);
		System.out.println(t.College);
		System.out.println(t.topic);
			
	}
	
	
}









