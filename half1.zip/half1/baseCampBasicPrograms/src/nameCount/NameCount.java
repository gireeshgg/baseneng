package nameCount;
import java.util.*;
public class NameCount {
public static void main(String[] a) {
	Scanner sc =new Scanner(System.in);
	HashMap<String,Integer> s=new HashMap<String,Integer>();
	
	String name;
	
	while(sc.hasNext()) {		
		name=sc.next();
		if(name.equals(".")) {
			break;
		}
		if(s.get(name)!=null) {
			s.put(name, s.get(name)+1);
		}else {
			s.put(name, 0);
	    }
		
	}
		int max=-1;
		String person="";
				
		for(String key:s.keySet()) {
			
			if(max<s.get(key)) {
				max=s.get(key);
				person=key;
				}else
			if(max==s.get(key)) {
				if(key.compareTo(person)<0) {
					person=key;
				}
			}
			System.out.println(key+" : "+(s.get(key)+1));
		}
		
	System.out.println("Winner is "+person);
	sc.close();
}
}
