package objArray;
import java.util.*;

public class ArrayofCampusMind {
public static void main(String[] a){
	Scanner sc=new Scanner(System.in);
	CampusMind obj[]=new CampusMind[5];
	obj[0]=new CampusMind("M1","Mahesh","Engineer",50.2);
	obj[1]=new CampusMind("M2","Ramesh","Engineer",51.0);
	obj[2]=new CampusMind("M3","sumesh","Engineer",53.0);
	obj[3]=new CampusMind("M4","kamesh","Engineer",55.0);
	obj[4]=new CampusMind("M5","bumesh","Engineer",59.0);
	for(int i=0;i<5;i++) {
		obj[i].show();
	}
	System.out.println();
	for(int i=0;i<5;i++) {
		double max=-1;
		int index=-1;
		for(int j=i;j<5;j++) {
			if(obj[j].percent>max) {
				max=obj[j].percent;
				index=j;
			}	
		}
		CampusMind temp=new CampusMind();
		temp=obj[i];
		obj[i]=obj[index];
		obj[index]=temp;
	}
	
	for(int i=0;i<5;i++) {
		obj[i].show();
	}
	System.out.println("Enter MID to be searched");
	String mid=sc.next();
	for(int i=0;i<5;i++) {
		if(mid.equals(obj[i].Mid)) {
			obj[i].show();
		}
	}
	
	
	sc.close();
}
}
