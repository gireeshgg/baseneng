package objArray;

public class CampusMind {
		
	 	String Mid;
		String Name;
		String Qualification;
		double percent;
		CampusMind(){};
		public CampusMind(String Mid,String Name,String Qualification,double percent) {
			this.Mid=Mid;
			this.Name=Name;
			this.Qualification=Qualification;
			this.percent=percent;
		}
		
		   
		public void show() {
			System.out.print(Mid+" ");
			System.out.print(Name+" ");
			System.out.print(Qualification+" ");
			System.out.println(percent);
		}
	}

