package countOfCharacterTypes;
import java.util.*;
public class CountOfCharacterTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter a String");
         String s=sc.nextLine();
         int countNum=0;
         int countUp=0;
         int countLw=0;
         int countSp=0;
         int countSpcl=0;
         for(int i=0;i<s.length();i++) {
        	 if(s.charAt(i)==32) {
        		 countSp++;
        	 }else if(s.charAt(i)>48 && s.charAt(i)<58 ) {
        		 countNum++;
        	 }else if(s.charAt(i)>64 && s.charAt(i)<91 ) {
        		 countUp++;
        	 }else if(s.charAt(i)>96 && s.charAt(i)<123 ) {
        		 countLw++;
        	 }else 
        		 countSpcl++;
        	 }
         
	System.out.println("Numbers:"+countNum+"\nSpaces:"+countSp+"\nUpper case letters:"+countUp+"\nLower case letters:"+countLw+"\nSpecial Characters:"+countSpcl);
	sc.close();
	}

}
