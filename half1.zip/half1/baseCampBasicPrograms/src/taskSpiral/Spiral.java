//program stores the gives array in spiral order 
/*example 
 given array is 
	1  2  3  4  5
	6  7  8  9  10
	11 12 13 14 15	
	16 17 18 19 20 
	21 22 23 24 25
output is 
	1  2  3  4  5                   
        16 17 18 19 6		
	15 24 25 20 7
        14 23 22 21 8
        13 12 11 10 9
	
	
*/
package taskSpiral;
import java.util.*;
public class Spiral {
 public static void main(String[] a1) {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter row and column size");
	 int n=sc.nextInt();
	 int m=sc.nextInt();
	 int len=n*m;
	 int []a=new int[len];
	 int[][]b=new int[n][m];
	 
	 	int k=n,l=m;
		 int i=0,I=i;
		 int j=0,J=j;
		 int x=0;
	 for(int g=0;g<len;g++) {                      //input
	    	a[g]=sc.nextInt(); 
	    }
	 

	 while(n>0 &&m>0) {
		J=0;
		if(x>=len)break;
		 while(J<n&&x<25) {
			b[i][j]=a[x++];							//forward
			 J++;
			 j++;
		 }
		 I=0;
		 i++;j--;
		 if(x>=len)break;							//down
		 while(I<m-2&&x<25) {
			b[i][j]=a[x++];
			 I++;
			 i++;
		 };
		 J=0;
		 if(x>=len)break;							//backward
		 while(J<n&&x<25) {
			 b[i][j]=a[x++];
			 J++;
			 j--;
		 }I=0;
		 
		 j++;i--;								//up 
		 if(x>=len)break;
		 while(I<m-2 && x<25) {
			 b[i][j]=a[x++];
			 I++;
			 i--;
		 }j++;i++;
		 n-=2;
		 m-=2;
		
	 }
    for(int g=0;g<k;g++) {                         //output
    	for(int h=0;h<l;h++) {
    		System.out.print(b[g][h]+" ");
    	}System.out.println();
    }
	 
	 
	 
	sc.close();
 }
}
