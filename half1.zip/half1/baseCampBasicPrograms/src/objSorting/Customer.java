package objSorting;

public class Customer {
		String Name;
		int Nitems;
		double bAmount;
		
		public Customer(){};
		public Customer(String Name,int Nitems,double bAmount) {
			this.Nitems=Nitems;
			this.Name=Name;
			this.bAmount=bAmount;
		}
		
		
		   
		public String getName() {
			return Name;
		}
		
		public int getNitems() {
			return Nitems;
		}
		
		public double getbAmount() {
			return bAmount;
		}
		
		public void show() {
			System.out.print(Name+" ");
			System.out.print(Nitems+" ");
			System.out.println(bAmount);
		}
		
}
		
		

