package objSorting;

import java.util.Scanner;

public class ObjSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		Customer obj[]=new Customer[5];
		obj[0]=new Customer("abhi",10,1005.20);
		obj[1]=new Customer("anaga",12,900);
		obj[2]=new Customer("aashit",8,905.0);
		obj[3]=new Customer("akash",15,1500);
		obj[4]=new Customer("amar",11,1000);
		int n=5;
		for(int i=0;i<n;i++) {
			obj[i].show();
		}
		
		//Selection sort-------------------------------------------no of items
		System.out.println();
		for(int i=0;i<n;i++) {
			double max=-1;
			int index=-1;
			for(int j=i;j<n;j++) {
				if(obj[j].getNitems()>max) {
					max=obj[j].getNitems();
					index=j;
				}	
			}
			Customer temp=new Customer();
			temp=obj[i];
			obj[i]=obj[index];
			obj[index]=temp;
		}
		System.out.println("\nSorted Based  on no of itmes \n");
		for(int i=0;i<n;i++) {
			obj[i].show();
		}
		//Insertion sort-------------------------------------------names
		
		for(int i=0;i<n;i++) {
			for(int j=i;j>0;j--) {
				if(stringCompare(obj[j-1].getName(),obj[j].getName())>0) {
					Customer temp=new Customer();
					temp=obj[j-1];
					obj[j-1]=obj[j];
					obj[j]=temp;	
				}	
			}
			
		}
		System.out.println("\nSorted Based  on no of Names\n ");
		for(int i=0;i<n;i++) {
			obj[i].show();
		}
		
		

		for(int i=0;i<n;i++) {
			for(int j=0;j<n-1-i;j++) {
				if(obj[j].getbAmount()<obj[j+1].getbAmount()) {
					Customer temp=new Customer();
					temp=obj[j+1];
					obj[j+1]=obj[j];
					obj[j]=temp;	
				}	
			}	
		}
		System.out.println("\nSorted Based  on no of amount \n");
	
		for(int i=0;i<n;i++) {
			obj[i].show();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		sc.close();
	}

	 static int  stringCompare(String s,String s1) {
		  int length=s.length();
		  if(s.length()<s1.length()) {
			  length=s.length();
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return -1;
		  }else if(s.length()>s1.length()){
			  length=s1.length();
			  for(int x=0;x<length;x++) {
					if(s.charAt(x)<s1.charAt(x)) {
						return -1;
					}
					if(s.charAt(x)>s1.charAt(x)) {
						return 1;
					}
				}
			  return 1;
		  }
		  return 0;
	  }
	

}
