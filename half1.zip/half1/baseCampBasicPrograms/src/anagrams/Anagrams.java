package anagrams;
import java.util.*;
public class Anagrams {
 public static void main(String[] a){
	 Scanner sc =new Scanner(System.in);
	 int n=sc.nextInt();
	 int count=0;
	 for(int i=0;i<n;i++) {
		 String s=sc.next();
		 String s1=sc.next();
		 char[] c=s.toCharArray();
		 char[] c1=s1.toCharArray();
			 for(int j=0;j<s.length();j++) {
				 for(int k=0;k<s.length();k++) {
					
					 if(c[j]==c1[k]) {
						 c[j]='0';
						 c1[k]='1';
						 count++;
						 break;
					 }
					 
				 }
			 }
				 System.out.println(s.length()+s1.length()-(2*count));
			
	 }
	 
	 sc.close();
 }
 
}
