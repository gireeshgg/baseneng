package anagrams;
import java.util.*;
public class dummy {
	 public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a String");
		String n=sc.next();
		String s="";
	    for(int i=0;i<n.length();i++) {
	    	if(i==3) {
	    		s+='a';
	    	}else {
	    	s+=n.charAt(i);
	    	}
	    }
	    n=s;
	    System.out.println(n);
		
sc.close();
		}
}
