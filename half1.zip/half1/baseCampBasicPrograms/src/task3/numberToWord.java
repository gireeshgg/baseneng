package task3;
import java.util.*;
public class numberToWord {
	public static void main(String[] a) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		boolean teen=false;
		int i=-1;
		int count=-1;
		int [] d=new int[4];
		if(n==0){
			System.out.print("Zero");
		}
		else
		{
		while(n>0) {
			d[++i]=n%10;     
			n=n/10;			
			count++;      
		}
		for(int j=count;j>=0;j--) {
			switch(d[j]){
			case 0:if(j==0) {
							if(teen==true) {
								System.out.print("Ten");
							}else {
								System.out.print(" Zero ");
							}
					}
					break;
			case 1:if(j==2){
							System.out.print("one hundred  ");
							}
					else if(j==0) {
						          if(teen==true) {System.out.print(" Eleven");}
						          else {
						          System.out.print(" One ");
						          }
						  }
					if(j==1) {teen=true;}
					break;
			case 2:if(j==2) {System.out.print("Two hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Twelve");}
					              else{System.out.print(" Two ");
					              }
					            }
			
					else if(j==1) {System.out.print("Twenty");}
					
					break;

			case 3:if(j==2) {System.out.print("Three hundred  ");}
					else if(j==0){if(teen==true) {System.out.print(" Thirteen");}
			          else {
									System.out.print(" Three ");
									}
					}
					else {
						if(j==1) {System.out.print("Thirty");}
					}
					
					break;

			case 4:if(j==2) {System.out.print("Four hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Forteen");}
					             else{
					            	System.out.print(" Four ");
						            }
					               }
					else {if(j==1) {System.out.print("Forty");}}
					
					break;

			case 5:if(j==2) {System.out.print("Five hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Fifteen");}
									else{
										System.out.print(" Five ");
										}
								}
					else {if(j==1) {System.out.print("Fifty");}}

					break;

			case 6:if(j==2) {System.out.print("Six hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Sixteen");}
									else{
										System.out.print(" Six ");
									}
								}
					else {if(j==1) {System.out.print("Sixty");}}

					break;

			case 7:if(j==2) {System.out.print("Seven hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Seventeen");}
											else{
												System.out.print(" Seven ");
											}
								}
					else {if(j==1) {System.out.print("Seventy");}}
			
					break;

			case 8:if(j==2) {System.out.print("Eight hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Eightteen");}
									else{
										System.out.print(" Eight ");
										}
								}
					else {if(j==1) {System.out.print("Eighty");}}

					break;
			case 9:if(j==2) {System.out.print("Nine hundred  ");}
					else if(j==0){if(teen==true) {System.out.print("Ninteen");}
								else{
									System.out.print(" Nine ");
								}
							}
					else {if(j==1) {System.out.print("Ninty");}}

					break;

			default:;
			}	
		  }
		}
		sc.close();
	}	
}


