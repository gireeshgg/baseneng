package task1;
import java.util.*;
public class Task1 {
 public static void main(String[]a) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int[] arr=new int[n];
	int secLarge=-1;
	int Large=-1;
	for(int i=0;i<n;i++) {
		arr[i]=sc.nextInt();
		if(arr[i]>Large) {
			Large=arr[i];
          }
		if(arr[i]>secLarge && arr[i]!=Large) {
			secLarge=arr[i];
		}	
	}
	
	System.out.println(secLarge);
	sc.close();
 }
}
