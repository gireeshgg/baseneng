package romanNumber;

import java.util.*;

public class RomanToDecimal {

	public static void main(String [] a) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Roman Number");
		String n=sc.next();
		int sum=0;
		int count=0;
		boolean valid=true;
		Map<Character, Integer> value = new HashMap<Character, Integer>();
		value.put('I', 1);
		value.put('V', 5);
		value.put('X', 10);
		value.put('L', 50);
		value.put('C', 100);
		value.put('D', 500);
		value.put('M', 1000);
		sum=value.get(n.charAt(n.length()-1));
		for(int j=n.length(), i=n.length()-2;i>=0;i--) {
			if(n.charAt(--j)==n.charAt(j-1)) {
				count++;
			}else{
				count=0;
			}
			if(count<3) {
			if(value.get(n.charAt(i))<value.get(n.charAt(i+1))) {
				sum=sum-value.get(n.charAt(i));
			}else {
				sum=sum+value.get(n.charAt(i));
			}
			
		}else{
			if(n.charAt(j)=='M') {
				continue;
			}
			System.out.print("Invalid Roman number ");
			valid=false;
			break;
		}
		
		}
		if(valid) {
			System.out.print(sum);
		}
			
		
		sc.close();
	}
}
