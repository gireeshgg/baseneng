package romanNumber;

import java.util.Scanner;

public class DecimalToRomanNumber {
	public static void main(String[] a) {
			Scanner sc = new Scanner(System.in);
			int n=sc.nextInt();
			
			int i=-1;
			int count=-1;
			int [] d=new int[4];
			if(n==0){
				System.out.print("There is no Zero in Roman Numbers!!!!!!");
			}
			else
			{
			while(n>0) {
				
				d[++i]=n%10;     
				n=n/10;			
				count++;  
				
				
			}
			for(int j=count;j>=0;j--) {
				if(j==3) {
					for(int k=0;k<d[j];k++) {
						System.out.print("M");
					}
				}
				switch(d[j]){
				case 10:if(j==0){
									System.out.print("X");
						}
						break;
				case 1:if(j==2){
								System.out.print("C");
								}
						else if(j==0) {
							          System.out.print("I");
							          }
							  
						if(j==1) {System.out.print("X");}
						break;
				case 2:if(j==2) {System.out.print("CC");}
						else if(j==0){
						              System.out.print("II");
						              
						            }
				
						else if(j==1) {System.out.print("XX");}
						
						break;

				case 3:if(j==2) {System.out.print("CCC");}
						else if(j==0){
										System.out.print("III");
										
						}
						else {
							if(j==1) {System.out.print("XXX");}
						}
						
						break;

				case 4:if(j==2) {System.out.print("CD");}
						else if(j==0){
						            	System.out.print("IV");
							            
						               }
						else {if(j==1) {System.out.print("XL");}}
						
						break;

				case 5:if(j==2) {System.out.print("D");}
						else if(j==0){
											System.out.print("V");
											
									}
						else {if(j==1) {System.out.print("L");}}

						break;

				case 6:if(j==2) {System.out.print("DC");}
						else if(j==0) {
											System.out.print("VI");
										
									}
						else {if(j==1) {System.out.print("LX");}}

						break;

				case 7:if(j==2) {System.out.print("DCC");}
						else if(j==0){
													System.out.print("VII");
												}
									
						else {if(j==1) {System.out.print("LXX");}}
				
						break;

				case 8:if(j==2) {System.out.print("DCCC");}
						else if(j==0){
											System.out.print("VIII");
											}
									
						else {if(j==1) {System.out.print("LXXX");}}

						break;
				case 9:if(j==2) {System.out.print("CM");}
						else if(j==0){
										System.out.print("IX");
									}
								
						else {if(j==1) {System.out.print("XC");}}

						break;

				default:;
				}	
			  }
			}
			sc.close();
		}	
			
		
		
	

}
