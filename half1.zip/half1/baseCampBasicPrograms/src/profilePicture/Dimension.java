package profilePicture;
import java.util.*;
public class Dimension {
	public static void main(String[] a){
		Scanner sc =new Scanner(System.in);
		int d=sc.nextInt();
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
			int h=sc.nextInt();
			int w=sc.nextInt();
			if(h<d) {
				System.out.println("CROP IT");
			}else if(h>d) {
				System.out.println("UPLOAD ANOTHER");
			}else {
				if(w>d) {
					System.out.println("CROP IT");
				}else if(w<d) {
					System.out.println("UPLOAD ANOTHER");
				}else {
					System.out.println("ACCEPTED");
				}
			}
		}
		sc.close();
	}
}
