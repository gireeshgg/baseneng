package trycatch;
import java.util.*;
public class Trycatch {
 public static void main(String [] args){
	 Scanner sc=new Scanner(System.in);

	
 try {
  
		
	int  n=1/0;
	System.out.print(n);	
	 }catch(Exception e) {
		 System.out.println("Entered type is not int");
		
	 }
	 
	
  System.out.println("Now u Did it right :)");
sc.close();
 }
}
