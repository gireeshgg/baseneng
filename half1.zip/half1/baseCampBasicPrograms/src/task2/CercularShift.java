package task2;
import java.util.*;
public class CercularShift {                                //  circular shift
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Shift Count:");
		int n=sc.nextInt();
		
		System.out.println("Enter Array Length:");
		int length=sc.nextInt();
		
		if(n<0) {
			n=n+length;
		}
		
		System.out.println("Enter Array elements:");
		int[] arr=new int[length];
		
		for(int i=0;i<length;i++) {
			arr[(i+n)%length]=sc.nextInt();	
		}
		
		for(int j=0;j<length;j++) {
			System.out.print(arr[j]+" ");
		}
		
		sc.close();
	}

}
