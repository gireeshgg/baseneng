package stringRotation;
import java.util.*;
import mypackages.*;
public class StringRotation {
	
	public static void main(String[] args) {
		GG a =new GG();
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] ans=new int[n];
		for(int i=0;i<n;i++) {
			String s=sc.next();
			String s1=sc.next();
			if(s.length()==s1.length()) {
				for(int j=0;j<s.length();j++){
					if(s.charAt(j)==s1.charAt(0)){
						String sub=a.Substring(j,s.length(),s) + a.Substring(0,j,s);
						if(a.Equal(sub,s1)) {
							ans[i]=1;
							break;
							
						}
					}
				}
			}
			System.out.println(ans[i]);
		  }
		
		
	sc.close();
	}



}
