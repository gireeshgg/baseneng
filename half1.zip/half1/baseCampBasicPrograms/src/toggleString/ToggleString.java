package toggleString;
import java.io.*; 
public class ToggleString {
 public static void main(String[] a)throws IOException {
   
	 BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	 String s=br.readLine();
	 for(int i=0;i<s.length();i++) {
		 if(Character.isUpperCase(s.charAt(i))) {
			 System.out.print(Character.toLowerCase(s.charAt(i)));
		 }else {
			 System.out.print(Character.toUpperCase(s.charAt(i)));
		 }
	 }
	 
 }
}
