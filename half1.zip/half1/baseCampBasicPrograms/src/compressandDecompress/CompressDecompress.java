/*Compress a gives string to small length and and decompress it to get the same string which is given as input
 string can contain any inputable character from the keyboard.  i.e numbers and  special characters */
		// TODO Auto-generated method stub
		package compressandDecompress;

		import java.util.*;

		public class CompressDecompress {
			public static void main(String[] a) {
				Scanner sc = new Scanner(System.in);
				String s = sc.next();
				int count = 1;
				String msg = new String();
				String dupMsg = new String();
				for (int i = 0; i < s.length(); i = i + count) {                             //compression part
					count = 1;
					msg = msg + s.charAt(i);
					dupMsg = dupMsg + s.charAt(i);
					for (int j = i; j < s.length(); j++) {
						if (j + 1 < s.length()) {
							if (s.charAt(j) == s.charAt(j + 1)) {
								count++;
							} else {
								break;
							}

						}
					}
					if (count > 2) {
						msg = msg + count;
						if (count < 20) {

							dupMsg = dupMsg + (char) count;
						} else {

							int reminder = count % 20;
							int dev = count / 20;
							for (int m = 0; m < dev; m++) {
								dupMsg = dupMsg + (char) 20;
							}
							dupMsg = dupMsg + (char) reminder;

						}
					}
					if (count == 2) {
						msg = msg + s.charAt(i);
						dupMsg = dupMsg + s.charAt(i);

					}

				}
				System.out.println("Compressed message :" + msg);			//compressed message
			   

				String deCompressed = new String();					//decompression part
				int num = 0;
				int z = 0;
				for (int k = 0; k < dupMsg.length(); k++) {
					num = 0;
					if ((int) dupMsg.charAt(k) > 31 && (int) dupMsg.charAt(k) < 128) {
						deCompressed = deCompressed + dupMsg.charAt(k);
					} else {
						z = k;
						while (dupMsg.charAt(z) < (char) 31) {
							num += dupMsg.charAt(z);
							z++;
							if(z==dupMsg.length()) {
								break;
								
							}
						}

						for (int l = 0; l < num - 1; l++) {
							deCompressed = deCompressed + dupMsg.charAt(k-1);
						}
						k = z - 1;
					}

				}

				System.out.println(deCompressed);						//decompressed message

				sc.close();
			}

	}


