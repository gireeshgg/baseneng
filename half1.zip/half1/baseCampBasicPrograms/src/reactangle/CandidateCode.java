package reactangle;

import java.util.*;
class Rectangle{
    int height;
    int width;
   
    void display(){
        System.out.println(height+" "+width);
    }
}

class RectangleArea  extends Rectangle{
    Scanner sc=new Scanner(System.in);
    RectangleArea(){super();}
    public void read_input(){
        height=sc.nextInt();
        width=sc.nextInt();
        super.display();
        display();
    }
    
    public void display(){
        System.out.println(height*width);
    }
}



public class CandidateCode {
   public static void main(String args[] ) throws Exception {

	//Write code here
	RectangleArea a=new RectangleArea();
	a.read_input();

   }
}