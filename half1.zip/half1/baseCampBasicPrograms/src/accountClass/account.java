package accountClass;
public class account{
	private String name;
	private int accNum;
	private float balance;
	private float rate;
	
	public account(String name, int accNum, float balance) {
		super();
		this.name = name;
		this.accNum = accNum;
		this.balance = balance;
	}
	float getAccountNum() {
		return accNum;
	}
	float interestPerYear() {
		return balance*rate;
	}
	float deposit(float dep) {
		balance+=dep;
		return balance;
	}
	float withdraw(float w) {
	
		balance-=w;
		return balance;
	}	
	public void showaccountDetails() {
	System.out.println(name+" "+accNum+" "+balance+" "+interestPerYear());
	}

}

 
class  saving extends account{
	 float rate=2;

	public saving(String name, int accNum, float balance) {
		super(name, accNum, balance);	
	}

		 
	 
 }
 
 
 
class fixedDeposit extends account{
	 float rate=4;

	public fixedDeposit(String name, int accNum, float balance) {
		super(name, accNum, balance);
	}
	 
}
