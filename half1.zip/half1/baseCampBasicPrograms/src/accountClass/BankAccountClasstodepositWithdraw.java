package accountClass;
import java.util.*;



class BankAccountClasstodepositWithdraw{
	static Scanner sc=new Scanner(System.in);
	static account []a=new account[10];
	static int i=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		boolean flag=true;
		while(flag) {
			System.out.println("Bank Account Info: Saving Acccount(SB)  Fixed Deposit(FD)");
	        switch(sc.nextLine()) {   
	        case "SB":System.out.println("Enter account details\nName Account_Number Balance ");
	        		  try {
	        		  a[i++]=new saving(sc.nextLine(),sc.nextInt(),sc.nextFloat());
	        		  System.out.println("do you want to Add More Account:Y->(1) / N->(0)");
	      				int n=sc.nextInt();sc.nextLine();
	      				if(n==1) {
	      					continue;		
	      				}
	        		  }catch(Exception ex) {
	        			  System.out.println("Account Not Created");
	        			  System.out.println("Type in same as inside the bracket(SB)/(FD");
	        			  continue;
	        		  }
	        		  break;
	        case "FD":System.out.println("Enter account details\nName Account_Number Balance ");sc.nextLine();
	       			 try {
	       				 a[i++]=new fixedDeposit(sc.nextLine(),sc.nextInt(),sc.nextFloat());
	       				System.out.println("do you want to Add More Account:Y->(1) / N->(0)");
	      				int n=sc.nextInt();sc.nextLine();
	      				if(n==1) {
	      					continue;		
	      				}
	       			 }catch(Exception ex) {
	       				 System.out.println("Account Not Created");
	       				 System.out.println("Type in same as inside the bracket(SB)/(FD)");
	       				 continue;
	       			 }
	       			  break;
	       	default:
	        }
			
	        Menu();
			System.out.println("do you want to countinue:1/0");
			int n=sc.nextInt();
			if(n==0) {
					break;		
				}
		}
	}
	
	static void Menu() {
		
		System.out.println("enter 1:deposit 2: withdraw 3:account details");

		switch(sc.nextInt()){
		case 1:	System.out.println("Enter Account Number and Amount:");	
						try {
						a[search(sc.nextInt())].deposit(sc.nextInt());
						}
						catch(NullPointerException e) {
							System.out.println("Account Number Not Found");
						}
						catch(InputMismatchException e1) {
							System.out.println("Input Miss  Match");
						}
						catch(Exception e2) {
							System.out.println("Account Number Not Found");
						}
				
				break;
		case 2: System.out.println("Enter Account Number and Amount:");				
				try {
					a[search(sc.nextInt())].withdraw(sc.nextInt());
		      		}
		      	catch(NullPointerException e) {
		      		System.out.println("Account Number Not Found");
		      	}
				catch(InputMismatchException e1) {
					System.out.println("Input Miss  Match");
				}
				catch(Exception e2) {
					System.out.println("Account Number Not Found");
				}
		        break;
		case 3: System.out.println("Enter AccountNumber");
				try {
		        a[search(sc.nextInt())].showaccountDetails();
				}
				catch(NullPointerException e) {
					System.out.println("Account Number Not Found");
				}
				catch(InputMismatchException e1) {
					System.out.println("Input Miss  Match");
				}
				catch(Exception e2) {
					System.out.println("Account Number Not Found");
				}
		
		
				break;
		default:
		}
	}
	
	static int search(int an) {
		int j=-1;
		for(int i=0;i<5;i++) {
			if(a[i].getAccountNum()==an) {
				return i;
			}
		}
		return j;
	}
}

