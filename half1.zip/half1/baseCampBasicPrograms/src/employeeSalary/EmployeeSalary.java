/*
 *
3.1. Objective: 
Through this application, participants will be able to implement different OOP ideas, such as how to create class, object, and constructor, how to call base class constructors using �super� keyword explicitly, inheritance, dynamic polymorphism etc. 
3.2. Problem Statement: 

The application will be used to calculate and display salary of different types of employees, such as Developer, Manager, Human Resource people etc. 
3.3. Description: 

Create a console application, which will: 
a. Create an array to store at least two Developer and two Hr class object references. 
b. Ask for all the necessary inputs regarding Developer or Hr and then create the objects 
c. Iterate through the array and display salary of the particular employee 
3.4. Note: 
I. Refer the following images for the creation of classes and expected output. 
II. The same method to calculate salary should be present in the base, Employee class, as well as derived classes, i.e., Developer and Hr classes. 
III. Assigning values to the fields of the classes should be done through overloaded constructors 
IV. Child class constructor should call overloaded constructor of the base class explicitly to by-pass all the values to the base class, and get all the common fields assigned there in the base class itself 
 * 
 * 
 * 
 */ 
  package employeeSalary;
 
import java.util.*;
class Employee{
	String name;
	int id;
	double basicPay;
	double daPay;
	double hraPay;	
	double totalSalary;
	
		public Employee(int id, String name,double basicPay, double daPay, double hraPay) {
		this.basicPay = basicPay;
		this.daPay = daPay;
		this.hraPay = hraPay;
		this.id = id;
		this.name = name;
	}
	
	


	double CalSal() {
		return totalSalary=basicPay+daPay+hraPay;
	}
	
	 @Override																						//overriding toString method to display object contents
	    public String toString() { 
	        return String.format(id + " " +name + " " +totalSalary+ " " ); 
	    } 
}

class dev extends Employee{
	double incentivePay;
																									//developer class with incentive as data member
	dev(int id, String name,double basicPay, double daPay,double incentivePay) {
	super(id, name, basicPay,  daPay, 0);
	this.incentivePay =incentivePay;
	}
	double CalSal() {
		return totalSalary=basicPay+incentivePay+daPay;
	}
	
}

class hr extends Employee{
	double gratuityPay;
																									//HR class with gratuityPay as data member
	public hr(int id, String name,double basicPay, double hraPay,double gratuityPay) {
		super(id, name, basicPay, 0, hraPay);
		this.gratuityPay = gratuityPay;
	}
	double CalSal() {
		return totalSalary=basicPay+gratuityPay+hraPay;
	}
}



public class EmployeeSalary {
static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println("Enter Number of Employees");
	int n=sc.nextInt();	
    Employee[] e=new Employee[n];
    for(int i=0;i<n;) {
    	System.out.println("Enter 1:developer  2:HR");
    	int choice=sc.nextInt();
    	
    	switch(choice){
    	case 1:try{ System.out.println("ID NAME BASICPAY DAPAY/HRAPAY GRATUITY/INCENTIVE");
    				e[i]=new dev(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
    				e[i].CalSal();																														//object creation with exception handling
    				i++;																																//object is created and linked to array when there is no exception in any input
    				
    				
    				}
    				catch(InputMismatchException E) {
    						System.out.println("Input Miss Match.Input according on the label....Object Not Created");
    						
    						
    				}
    				sc.nextLine();                // scanner value clearing
    				break;
    	
    	case 2:try {System.out.println("ID NAME BASICPAY DAPAY/HRAPAY GRATUITY/INCENTIVE");
    				e[i]=new hr(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
    				e[i].CalSal();
    				i++;
    				
    				}
    				catch(InputMismatchException E) {
    						System.out.println("Input Miss Match.Input according on the label....Object Not Created");
    				}
    				sc.nextLine();               //Scanner value clearing
    				break;
    	default: System.out.println("Enter only 1 or 2 ");
    	}
    	
    }
    
    
    for(int i=0;i<n;i++)																																//Display all the objects with calculated salaries
    {
    	System.out.println(e[i]);
    }
	}

}
