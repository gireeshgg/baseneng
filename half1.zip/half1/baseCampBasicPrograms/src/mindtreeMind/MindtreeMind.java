package mindtreeMind;

public class MindtreeMind {
	
 	String Mid;
	String Name;
	String Qualification;
	double salary;
	MindtreeMind(){};
	public MindtreeMind(String Mid,String Name,String Qualification,double salary) {
		this.Mid=Mid;
		this.Name=Name;
		this.Qualification=Qualification;
		this.salary=salary;
	}
	
	   
	public void show() {
		System.out.print(Mid+" ");
		System.out.print(Name+" ");
		System.out.print(Qualification+" ");
		System.out.println(salary);
	}
}
