package mindtreeMind;

import java.util.Scanner;


public class ArrayMinds {
public static void main(String[] a){
	Scanner sc=new Scanner(System.in);
	MindtreeMind obj[]=new MindtreeMind[5];
	obj[0]=new MindtreeMind("M1","Mahesh","Engineer",50000);
	obj[1]=new MindtreeMind("M2","Ramesh","Engineer",51000);
	obj[2]=new MindtreeMind("M3","sumesh","Engineer",53000);
	obj[3]=new MindtreeMind("M4","kamesh","Engineer",55000);
	obj[4]=new MindtreeMind("M5","bumesh","Engineer",59000);
	for(int i=0;i<5;i++) {
		obj[i].show();
	}
	System.out.println();
	for(int i=0;i<5;i++) {
		double max=-1;
		int index=-1;
		for(int j=i;j<5;j++) {
			if(obj[j].salary>max) {
				max=obj[j].salary;
				index=j;
			}	
		}
		MindtreeMind temp=new MindtreeMind();
		temp=obj[i];
		obj[i]=obj[index];
		obj[index]=temp;
	}
	
	for(int i=0;i<5;i++) {
		obj[i].show();
	}
	System.out.println("Enter MID to be searched");
	String mid=sc.next();
	boolean flag=true;
	for(int i=0;i<5;i++) {
		if(mid.equals(obj[i].Mid)) {
			obj[i].show();
			flag=false;
			break;
		}
	}
	if(flag) {
		System.out.println("Sorry...Not found any match");
	}
	
	sc.close();
}
}
