package isbn;
import java.util.*;
public class Isbn {
 public static void main(String[] a) {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter ISBN:");
	 int n=sc.nextInt();
	 int[]d=new int[12];
	 int i =-1;
	 int j=10;
	 int sum=0;
	 while(n>0) {
		 d[++i]=n%10;
		 n=n/10;
		 sum=sum+(d[i]*(j--));
	 }
	 if(sum%11==0)
	 {
		 System.out.println("Leagal ISBN");
	 }
	 else {
		 System.out.println("Illegal ISBN ");
	 }
	 sc.close();
 }
}
