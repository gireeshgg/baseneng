package com.mindtree.dao;

import java.util.ArrayList;

import com.mindtree.entity.Account;
import com.mindtree.entity.Transaction;
import com.mindtree.exceptions.InvalidAccountNumberException;

public interface Dao {
	    public void createConnection();
	    
		public void deposit(int transactionId,Account ac, double amount)  ;

		public void withDraw(int transactionId,Account ac, double amount) ;

		public int createAccount(Account ac) ;

		public Account getAccount(long accNo) throws InvalidAccountNumberException;

		public void transferFunds(int transactionId,Account fromAccount, Account toAccount, double amount) ;
		
		public int validateLogIn(Account ac) ;
		
		public ArrayList<Transaction> getTransactions(String accNo);
		
		public Transaction getParticularTransaction(int transactionId,String accNo);
	    
		public void closeConnection();
}
