package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class AccountCreationException extends BankingApplicationException {
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Account Creation Cancelled";
}
}

