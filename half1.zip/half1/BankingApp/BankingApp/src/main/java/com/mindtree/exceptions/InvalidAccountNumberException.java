package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class InvalidAccountNumberException extends Exception {
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Invalid Acc No";
}
}
