package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class InsufficientBalanceException extends BankingApplicationException {
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Insufficient Funds";
}
}
