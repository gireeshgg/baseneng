package com.mindtree.testController;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.entity.Transaction;

public interface TestController {
	public String createAccountPage(); //go to account creation page
	
	public String signUpPage();   //sign up page
	
	public String logInPage();  //log in page
	
	public ArrayList<Transaction> getTransactions();
	
	public Transaction getParticularTransaction(@PathVariable String id) ;
	
}
