package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class InvalidPanException extends Exception {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Invalid Pan";
	}
}
