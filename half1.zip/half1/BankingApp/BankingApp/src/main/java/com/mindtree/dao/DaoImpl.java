package com.mindtree.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mindtree.entity.Account;
import com.mindtree.entity.Transaction;
import com.mindtree.exceptions.InvalidAccountNumberException;
import com.mindtree.utility.DBUtil;

public class DaoImpl implements Dao {
	Connection con;
	Statement stmt;
	ResultSet rs;

	@Override
	public void deposit(int transactionId, Account ac, double amount) {
		createConnection();
		try {
			getUpdate(ac);
			stmt.executeUpdate(
					"insert into transaction(transaction_id,FromAccNo,F_accBalance,type,amount,current_f_accbalance,pan) values("
							+ transactionId + "," + ac.getAccountNumber() + "," + (ac.getBalance() - amount)
							+ ",'depoist'," + amount + "," + ac.getBalance() + ",'" + ac.getPanNumber() + "')");

		} catch (SQLException e) {
			System.out.println(e);
		}
		closeConnection();

	}

	public void getUpdate(Account ac) {
		try {
			stmt.executeUpdate(
					"update bankDetails set balance=" + ac.getBalance() + "where accNo=" + ac.getAccountNumber());
			rs = stmt.executeQuery("select pan from pan where accNo=" + ac.getAccountNumber());
			if (rs.first())
				ac.setPanNumber(rs.getString(1));
		} catch (SQLException e) {
			System.out.println(e);// TODO: handle exception
		}
	}

	@Override
	public void withDraw(int transactionId, Account ac, double amount) {
		// TODO Auto-generated method stub
		createConnection();
		try {
			getUpdate(ac);
			stmt.executeUpdate(
					"insert into transaction(transaction_id,FromAccNo,F_accBalance,type,amount,current_f_accbalance,pan) values("
							+ transactionId + "," + ac.getAccountNumber() + "," + (ac.getBalance() + amount)
							+ ",'WithDraw'," + amount + "," + ac.getBalance() + ",'" + ac.getPanNumber() + "')");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		closeConnection();

	}

	@Override
	public int createAccount(Account ac) {
		// TODO Auto-generated method stub
		int result = 0;
		createConnection();
		try {
			result = stmt.executeUpdate("insert into bankdetails values(" + ac.getAccountNumber() + ",\'"
					+ ac.getCustomerName() + "\'," + ac.getBalance() + ")");
			if (result == 0)
				return 0;
			result = stmt.executeUpdate(
					"insert into pan values(" + ac.getAccountNumber() + ",\'" + ac.getPanNumber() + "\')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		closeConnection();
		return result;
	}

	@Override
	public Account getAccount(long accNo) throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		createConnection();
		try {
			rs = stmt.executeQuery("select * from bankdetails where accno=" + accNo);
			if (!rs.first())
				throw new InvalidAccountNumberException();
			Account ac = new Account();

			ac.setAccountNumber(rs.getLong(1));

			ac.setCustomerName(rs.getString(2));
			ac.setBalance(rs.getDouble(3));

			closeConnection();
			return ac;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InvalidAccountNumberException();
		}
	}

	@Override
	public void transferFunds(int transactionId, Account fromAccount, Account toAccount, double amount) {

		createConnection();
		getUpdate(fromAccount);
		getUpdate(toAccount);
		try {
			stmt.executeUpdate("insert into transaction values(" + transactionId + "," + fromAccount.getAccountNumber()
					+ "," + (fromAccount.getBalance() + amount) + "," + toAccount.getAccountNumber() + ","
					+ (toAccount.getBalance() - amount) + ",'Transfer Funds'," + amount + "," + fromAccount.getBalance()
					+ "," + toAccount.getBalance() + ",'" + fromAccount.getPanNumber() + "')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		closeConnection();
		// TODO Auto-generated method stub

	}

	public void closeConnection() {
		if (con != null)
			try {
				con.close();
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public void createConnection() {
		DBUtil db;
		try {
			db = new DBUtil();
			con = db.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate("use BankApp");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public int validateLogIn(Account ac) {
		createConnection();
		int result = 0;
		try {

			rs = stmt.executeQuery(
					"select * from pan where accno=" + ac.getAccountNumber() + " and pan='" + ac.getPanNumber() + "'");
			rs.last();
			result = rs.getRow();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		closeConnection();
		// TODO Auto-generated method stub
		return result;
	}

	@Override
	public ArrayList<Transaction> getTransactions(String accNo) {
		// TODO Auto-generated method stub
		createConnection();
		ArrayList<Transaction> al = new ArrayList<Transaction>();
		Transaction ta = null;
		try {
			rs = stmt.executeQuery(
					"select transaction_id,F_accBalance,toAccNo,type,amount,current_f_accbalance from transaction where FromAccNo="
							+ accNo);

			while (rs.next()) {
				ta = new Transaction(rs.getInt(1), rs.getDouble(2), rs.getString(3), rs.getString(4), rs.getDouble(5),
						rs.getDouble(6));
				al.add(ta);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			return al;
		}
		return al;
	}

	public Transaction getParticularTransaction(int transactionId, String accNo) {
		// TODO Auto-generated method stub
		Transaction ta = null;
		createConnection();
		try {
			rs = stmt.executeQuery(
					"select transaction_id,F_accBalance,toAccNo,type,amount,current_f_accbalance from transaction where transaction_id"
							+ "=" + transactionId + " and FromAccNo=" + accNo);

			while (rs.next()) {
				ta = new Transaction(rs.getInt(1), rs.getDouble(2), rs.getString(3), rs.getString(4), rs.getDouble(5),
						rs.getDouble(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			return ta;
		}
		closeConnection();
		return ta;
	}

}
