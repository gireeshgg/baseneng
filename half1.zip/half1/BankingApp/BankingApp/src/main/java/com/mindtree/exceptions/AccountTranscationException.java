package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class AccountTranscationException extends BankingApplicationException {
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Transaction Cancelled";
}
}