package com.mindtree.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class OutputSet {
	int affectedRows;
	String accNo;
	String error;

	public OutputSet() {
		super();
		affectedRows = 0;
	}

	public OutputSet(int affectedRows, String accNo, String error) {
		super();
		this.affectedRows = affectedRows;
		this.accNo = accNo;
		this.error = error;
	}

	public int getAffectedRows() {
		return affectedRows;
	}

	public void setAffectedRows(int affectedRows) {
		this.affectedRows = affectedRows;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}