package com.mindtree.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDetail {
	private String customerName;
	private double balance;
    private String panNumber;
	public CustomerDetail( String customerName, double balance) {
		super();
		this.customerName = customerName;
		this.balance = balance;
	}

	public CustomerDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
}
