package com.mindtree.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Transaction {
	int transactionId;
	double oldBal;
	String toAccNo;
	String type;
	double amount;
	double currentBal;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, double oldBal, String toAccNo, String type, double amount,
			double currentBal) {
		super();
		this.transactionId = transactionId;
		this.oldBal = oldBal;
		this.toAccNo = toAccNo;
		this.type = type;
		this.amount = amount;
		this.currentBal = currentBal;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public double getOldBal() {
		return oldBal;
	}

	public void setOldBal(double oldBal) {
		this.oldBal = oldBal;
	}

	public String getToAccNo() {
		return toAccNo;
	}

	public void setToAccNo(String toAccNo) {
		this.toAccNo = toAccNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getCurrentBal() {
		return currentBal;
	}

	public void setCurrentBal(double currentBal) {
		this.currentBal = currentBal;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", oldBal=" + oldBal + ", toAccNo=" + toAccNo + ", type="
				+ type + ", amount=" + amount + ", currentBal=" + currentBal + "]";
	}

}
