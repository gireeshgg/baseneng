package com.mindtree.testController;

import java.util.ArrayList;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mindtree.dao.DaoImpl;
import com.mindtree.entity.Account;
import com.mindtree.entity.CustomerDetail;
import com.mindtree.entity.OutputSet;
import com.mindtree.entity.Transaction;
import com.mindtree.exceptions.AccountCreationException;
import com.mindtree.exceptions.InsufficientBalanceException;
import com.mindtree.exceptions.InvalidAccountNumberException;
import com.mindtree.exceptions.InvalidNameException;
import com.mindtree.exceptions.InvalidPanException;

@org.springframework.stereotype.Controller
@CrossOrigin(origins = "*")
public class TestControllerImpl implements TestController {
	OutputSet os;
	@RequestMapping(value = "/create")
	public String createAccountPage() {
		return "hello.html";
	}

	@RequestMapping(value="/dosomething",params="action", method = RequestMethod.GET)	
	public String signUpPage() {
    	return "SignUp.html";
   	}
	@RequestMapping(value="/dosomething",params="action2", method = RequestMethod.GET)	
	public String logInPage() {
    	return "Login.html";
   	}
	@ResponseBody
	@GetMapping(value="/getTransactions",produces= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public ArrayList<Transaction> getTransactions() {
		System.out.println(os.getAccNo());
		return new DaoImpl().getTransactions(os.getAccNo());
	}
	@ResponseBody
	@GetMapping(value="/getParticularTransaction/{id}",produces= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public Transaction getParticularTransaction(@PathVariable String id) {
		Transaction ta=new DaoImpl().getParticularTransaction(Integer.parseInt(id),os.getAccNo());
		return ta;
	}	
	
	@ResponseBody
	@PostMapping(value="/validate",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public OutputSet validate(@RequestBody Account ac) {
		int result = new DaoImpl().validateLogIn(ac);
		os=new OutputSet();
		os.setAffectedRows(result);
		os.setAccNo(""+ac.getAccountNumber());
		return os;
	}
	@ResponseBody
	@PostMapping(value="/createAccount",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public OutputSet createAccount(@RequestBody CustomerDetail cs) {
		try{
			if (cs.getBalance() < 500 ) {
				throw new AccountCreationException();
			}
		}catch (AccountCreationException e) {
			// TODO: handle exception
			os=new OutputSet();
			os.setError("Minimum required bal is 500");
			return os;
		}
		Account ac=new Account();
		ac.setCustomerName(cs.getCustomerName());
		ac.setBalance(cs.getBalance());
		ac.setPanNumber(cs.getPanNumber());
		String accNo = "50000" + (int) (Math.random() * (1000000000 - 99999999) + 99999999);
		ac.setAccountNumber(Long.parseLong(accNo));
		String panNo = ac.getPanNumber();
		try {
			validatePAN(panNo);
			validateName(ac.getCustomerName());
		} catch (InvalidPanException|InvalidNameException e) {
			// TODO Auto-generated catch block
			os=new OutputSet();
			os.setError(e.toString());
			return os;
					
		}
		int result = new DaoImpl().createAccount(ac);
		
		return new OutputSet(result,accNo,"No error");
	}
	@ResponseBody
	@PostMapping(value="/transfer",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public OutputSet transferFunds(@RequestBody Transaction t) {
		double amount=0;
		try {
		amount=t.getAmount();
		if(amount==0)
			throw new Exception();
		}
		catch (Exception e) {
			// TODO: handle exception
			return new OutputSet(0, null, "Invalid amount");
		}
		Account fromAccount=null;
		Account toAccount=null;
		try {
			fromAccount=getAccount(Long.parseLong(os.getAccNo()));
			try {
			toAccount=getAccount(Long.parseLong(t.getToAccNo())); }
			catch(Exception e) {throw new InvalidAccountNumberException(); }
			if(fromAccount.getBalance()<amount) {
			throw new InsufficientBalanceException();
			}
		}catch (InsufficientBalanceException|InvalidAccountNumberException e) {
			return new OutputSet(0, null,e.toString());	// TODO: handle exception
		}
		
		
		fromAccount.setBalance(fromAccount.getBalance() - amount);
		toAccount.setBalance(toAccount.getBalance() + amount);
		new DaoImpl().transferFunds(getTransactionID(), fromAccount, toAccount, amount);
			
		return new OutputSet(1, null, null);
	}
	public int getTransactionID() {
		// TODO Auto-generated method stub
		return (int)(Math.random() * (100000 - 9999) + 9999);
	}
	public void validatePAN(String pan) throws InvalidPanException {
		// TODO Auto-generated method stub
		if (pan.length() != 10 || !Character.isAlphabetic(pan.charAt(9))
				|| pan.substring(0, 5).replaceAll("[a-zA-Z]", "").length() > 0
				|| pan.substring(5, 9).replaceAll("[0-9]", "").length() > 0)
			throw new InvalidPanException();
	}
	public void validateName(String customerName) throws InvalidNameException {
		// TODO Auto-generated method stub

		if (customerName == null || customerName.equals("")||customerName.length()==0||customerName.replaceAll("[a-zA-Z]", "").length() > 0)
			throw new InvalidNameException();

	}
	
	public Account getAccount(long accNo) throws  InvalidAccountNumberException {
		// TODO Auto-generated method stub
		return new DaoImpl().getAccount(accNo);
	}

}