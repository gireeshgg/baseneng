package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class InvalidAmountException extends BankingApplicationException {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Invalid Amount";
	}
}