package com.mindtree.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import com.mindtree.dao.DaoImpl;
import com.mindtree.entity.Transaction;

class TestClass {

	@Test
	void testAllTransaction() {
		
	ArrayList<Transaction> t=null;
//		assertEquals(0, t.size());
		Transaction a=new Transaction( 98867 ,98765.0 , "50000283261488" , "Transfer Funds" , 100.0 ,98665.0);
		ArrayList<Transaction> tTest=new ArrayList<Transaction>();
		tTest.add(a);
		t=new DaoImpl().getTransactions("50000639769856");
		/*System.out.println(tTest.removeAll(t) ); */
		System.out.println(tTest);
		System.out.println(t);
		//assertEquals(tTest.equals(t), true);
		assertEquals(tTest.get(0).getToAccNo().equals(t.get(0).getToAccNo()) , true);
	}
	@Test
	void testParticularTransaction() {

		Transaction ta=new DaoImpl().getParticularTransaction(123,"123456");
		assertEquals(ta, null);	
	}

}
