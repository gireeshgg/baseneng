package checkObjectTypeCast;

class vehicle{
	
	void engin() {
		System.out.println("vehicle Engin..");
	}
	
}

class car extends vehicle{
	void engin() {
		System.out.println("Car Engin..");
	}
	void wheel() {
		System.out.println("wheel..");
	}
	
}

class auto extends vehicle{
	
}


public class check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    vehicle v=new car();
    vehicle v1=new auto();
    car c=new car();
    //car cv=new vehicle(); can't  do like this   
    v.engin();
    c.engin();
    v1.engin();
    
   // v.wheel(); can't do 
    
	}

}
