package arraySort;
import java.util.*;
class arrayEl{
	int [][]a;
	int [] out;

		
	
	public int[] arrangements(int [][]a) {
		out=new int[a[0].length*a.length];
		
		int in=0,ind=0;
		int pre=0,loop=0;;
		int z=0;
		int x=(a[0].length*a.length)/2;
		while(z<=x) {
			
	    	int min=9999999;
	    	for(int i=0;i<a.length;i++) {
	    		for(int j=0;j<a[0].length;j++) {
				if(a[i][j]<min) {
					min=a[i][j];
					in=i;ind=j;
				}
	    		}
	    	}
	    	a[in][ind]=999999;
	    	if(loop%2==0) {
	    		out[x-z]=min;
	    	}else {
	    		out[x+z]=min;
	    	}
	    if(loop%2==0) {
	    	z++;
	    }
	    loop++;
		}
	             
		return out;
	}
	
}

public class ArraySort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the dimensions n*m:");
		int n=sc.nextInt();
		int m=sc.nextInt();
		int [][]a=new int[n][m];
		int [] output=new int [n*m];
		System.out.println("Enter elements:");
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				a[i][j]=sc.nextInt();
				
			}
		}
		arrayEl ar=new arrayEl();
		output=ar.arrangements(a);
		for(int j=0;j<n*m;j++) {
			System.out.print(output[j]);
		}

	
	sc.close();
	}

}
