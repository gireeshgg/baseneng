package com.outstandingperson;

public class Professor extends Person {
private int booksPublished;

public Professor(String name,int booksPublished) {
	super(name);
	this.booksPublished = booksPublished;
}

public int getBooksPublished() {
	return booksPublished;
}

public void setBooksPublished(int booksPublished) {
	this.booksPublished = booksPublished;
}
public boolean outStanding() {
	if(booksPublished>=4)
		return true;
	return false;
}

public void print() {
	System.out.print(this.getName());
	System.out.println(" : "+booksPublished+" Books Published");
}

}
