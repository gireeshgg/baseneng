package com.outstandingperson;

public class Student extends Person {
private double percentage;

public Student(String name,double percentge) {
	super(name);
	this.percentage = percentge;
}

public double getPercentge() {
	return percentage;
}

public void setPercentge(int percentge) {
	this.percentage = percentge;
}
public void display() {
	System.out.print(this.getName());
	System.out.println(" : "+percentage+" Percentage");
	
}


public boolean outStanding() {
	if(percentage>=85)return true;
	return false;
}
}
