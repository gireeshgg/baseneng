package com.outstandingperson;
import java.util.*;
public class OutStandingPeron {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		Person[] p=new Person[5];
		String name=null;
		int books=0;
		double percent=0;
		System.out.println("..Wellcome..");
		for(int i=0;i<5;) {
			
			System.out.println("Enter Person    1 -> Professr\t\t2 -> Student  ");
			int c=0;
			try{
				 c=sc.nextInt();
				 
				}catch(InputMismatchException e) {
					System.out.println("Enter Integer only..!! \ntry again.");
					sc.nextLine();                                          //clearing the scanner
					continue;
				}
			boolean succ;
			switch(c) {
			case 1:
					do{ succ=false;
						System.out.println("Enter Professor name");
					try{
						name=sc.next();
					succ=true;
					}catch(InputMismatchException e) {
						System.out.println("Enter only String.  ex:Adi. \ntry again.");
						sc.nextLine();
					}
					}while(!succ);
					do{ 
						succ=false;
						System.out.println("Enter No of books Published");
						
						try{books=sc.nextInt();
						succ=true;
						}catch(InputMismatchException e) {
							System.out.println("Enter only Integer.  ex:4. \ntry again.");
							sc.nextLine();
						}
					}while(!succ);
					p[i++]=new Professor(name,books);
			break;
			case 2: 
					do{ succ=false;
						System.out.println("Enter Student name");
					try{name=sc.next();
					succ=true;
					}catch(InputMismatchException e) {
						System.out.println("Enter only String.  ex:Adi.\ntry again.");
						sc.nextLine();
					}
					}while(!succ);
					do {
						succ=false;
						System.out.println("Enter Percentage");
						try{percent=sc.nextDouble();
						succ=true;
						}catch(InputMismatchException e) {
							System.out.println("Enter only Double.  ex:65.0.\ntry again.");
							sc.nextLine();
						}
					}while(!succ);
					p[i++]=new Student(name,percent);
			break;
			default:System.out.println("Option not available!!");
			}
			if(i==5) {
				System.out.println("-----Input Operation Completed-------\n");
				break;
			}
		}
		System.out.println("The Outstanding Personals:");
		for(Person ps:p) {
			if(ps instanceof Professor) {
				if(ps.outStanding()) {
					((Professor)ps).print();
				}
			}
			if(ps instanceof Student) {
				if(ps.outStanding()) {
					((Student)ps).display();
				}
			}
		}




	}

}
