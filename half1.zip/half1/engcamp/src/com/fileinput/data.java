package com.fileinput;

public class data implements Comparable<data>{
	int product_id;
	String product_name;
	double price;
	String category;
	public data(int product_id, String product_name, double price, String category) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.price = price;
		this.category = category;
	}
	void show(String cat) {
		if(category.equals(cat)) {
		System.out.print(product_id+",   ");
		System.out.print(product_name+",            ");
		System.out.print(price+",              ");
		System.out.println(category+".");
		
		}
	}

	public int compareTo(data o) {
		return product_name.compareToIgnoreCase(o.product_name);
	}


	
}
