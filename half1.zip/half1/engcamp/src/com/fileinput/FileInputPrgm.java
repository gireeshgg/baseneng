package com.fileinput;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;


public class FileInputPrgm {

	public static void main(String[] args) throws IOException{
		boolean flag=true;
		List<data> list=new ArrayList<data>();
		try(FileInputStream	 fin=new FileInputStream(args[0]);
			Scanner sc=new Scanner(fin)){   
			sc.useDelimiter(",");
			while(sc.hasNextLine()) {
				int id=sc.nextInt();
				String name=sc.next();
				double price=sc.nextDouble();
				String cat=sc.next();
				//sc.nextLine();
				try {
					list.add(new data(id,name,price,cat));
				}catch(Exception e) {
					System.out.println("Object is not created!!.");
					}
			}
		}catch(IOException e) {
			System.out.println(e+"\nFile not found... Give currect file path and file name");
			flag=false;
			System.out.println("Thank You...");
		}
		
		
		
		if(flag) {
		Collections.sort(list);
		
			try(Scanner sc=new Scanner(System.in)){
		do {
			System.out.println("Enter Product Category to be Searched");
			String cat="";
			do{
				try{
					if(sc.hasNextInt()|sc.hasNextDouble()) {
						throw new InputMismatchException();
					} 
					cat=sc.nextLine();break;
				}catch(InputMismatchException e) {
					System.out.println(e+"\nEnter only String values...Try Again->");
					
				}
			}while(true);
			System.out.println();
			for(data a:list) {
				a.show(cat);
			}
			System.out.println();
			System.out.println("Enter 0 :to exit 1 :to Continue"); 
		
			if(sc.nextInt()==0) {
				System.out.println("Thank You....");
				break;
			}
		sc.nextLine();
		}while(true);
		}
		
	
		}
		
	}

}
