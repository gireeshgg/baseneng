package oopsconcept;

public class FourWheeler extends Vehicle{
	boolean started=false;
	 void start() {
		 if(started==false) {
		 started=true;
		 System.out.println("four wheeler started..");
	 }else
	 {
		 System.out.println("Vehicle already started!!!");
	 }
	 }
	 void stop() {
		 if(started==true) {
		 started=false;
		 System.out.println("four wheeler stoping..");
	 }else {
		 System.out.println("Four Wheeler is not in start state!!!");
	 }
	 }
	
	 
}
