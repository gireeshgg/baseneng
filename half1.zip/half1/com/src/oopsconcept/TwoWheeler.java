package oopsconcept;

public class TwoWheeler extends Vehicle {
	boolean started=false;
 void start() {
	 if(started==false) {
	 started=true;
	 System.out.println("two wheeler started..");
	 }else
	 {
		 System.out.println("Vehicle already started!!!");
	 }
	 
 }
 void stop() {
	 if(started==true) {
	 started=false;
	 System.out.println("two wheeler stoping..");
	 }else {
		 System.out.println("Two Wheeler is not in start state!!!");
	 }
	 
 }
 
 
}
