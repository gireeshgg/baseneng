package oopsconcept;
import java.util.*;
public class vhcl {
 public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
	 TwoWheeler v1=new TwoWheeler();
	 ThreeWheeler v2=new ThreeWheeler();
	 FourWheeler v3=new FourWheeler();
	 do {
		 System.out.println("Enter\n  1:Start Two Wheeler     2:Start Three wheeler     3:Start Four Wheeler");
		 System.out.println("  4:Stop Two Wheeler      5:Stop Three wheeler      6:Stop Four Wheeler\n  7:Stop All Vehicles");
		 switch(sc.nextInt()) {
		 case 1:v1.start();
			 	break;
		 case 2:v2.start();
			 	break;
		 case 3:v3.start();
			 	break;
		 case 4:v1.stop();
			 	break;
		 case 5:v2.stop();
			 	break;
		 case 6:v3.stop();
			 	break;
		 case 7: Vehicle.stop(v1,v2,v3);
		 		break;
		 default:System.out.println("Invalid choice");
		 }
		 System.out.println("ENTER : '1' to continue..  '0'  Otherwise ");
		 if(sc.nextInt()==0) {
			 System.out.println("THANK YOU....");
			 break;
		 }System.out.println("Continued....");
	 }while(true);
	 
	 
	sc.close(); 
 }
}
