package oopsconcept;

public abstract class Vehicle {
  abstract void start();
  static void stop(TwoWheeler a,ThreeWheeler b,FourWheeler c) {
	  System.out.println("Stoping All Vehicles....");
	  a.stop();
	  b.stop();
	  c.stop();
  }
}
