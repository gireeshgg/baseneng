/**
 * program imitates the basic working of vehicle start and stop.
 */
/**
 * @author M1049029
 *
 */
package oopsconcept;