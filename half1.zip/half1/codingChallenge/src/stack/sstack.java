package stack;
import java.util.*;

public class sstack {
	 static String[] braces(String[] values) {
	      String[] result=new String[values.length];
	        Stack <Character> s=new  Stack <>();
	        for(int i=0;i<values.length;i++){
	          if((values[i].length())%2==1){
	              result[i]="NO";
	          }else{
	              for(int j=0;j<values[i].length();j++){
	                  if((values[i].charAt(0)=='}')||(values[i].charAt(0)==']')||(values[i].charAt(0)==')')){
	                      result[i]="NO";
	                          break;
	                  }
	                  if(values[i].charAt(j)=='{') {
	                      s.push('}');
	                  }
	                  else if(values[i].charAt(j)=='['){
	                      s.push(']');
	                  }
	                  else if(values[i].charAt(j)=='('){
	                      s.push(')');
	                  }
	                  else{
	                      if(s.empty() ||  values[i].charAt(j)!=s.peek())
	                      {
	                          result[i]="NO";
	                          break;
	                      }
	                      s.pop();
	                  }
	              }
	                if(s.empty()){
	            result[i]="YES";
	            }else {
	            	result[i]="NO";
	            }
	                while(!s.empty()) {
	                	s.pop();
	                }
	            }
	          
	      }
	        
	    return result;       
	    }


	  private static final Scanner scanner = new Scanner(System.in);

	    public static void main(String[] args) {
	       // BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

	        int valuesCount = scanner.nextInt();
	        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

	        String[] values = new String[valuesCount];

	        for (int i = 0; i < valuesCount; i++) {
	            String valuesItem = scanner.nextLine();
	            values[i] = valuesItem;
	        }

	        String[] res = braces(values);

	        for (int i = 0; i < res.length; i++) {
	            System.out.println(res[i]);
	            System.out.println(values[i]);
	            if (i != res.length - 1) {
	               System.out.println();
	            }
	        }

	       

	        scanner.close();
	    }
	}

	
	


