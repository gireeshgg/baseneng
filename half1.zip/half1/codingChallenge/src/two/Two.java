package two;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;


class Result {

    /*
     * Complete the 'getTimes' function below.
     *
     * The function is expected to return an INTEGER_ARRAY.
     * The function accepts following parameters:
     *  1. INTEGER_ARRAY time
     *  2. INTEGER_ARRAY direction
     */

public static List<Integer> getTimes(List<Integer> time, List<Integer> direction) {
    // Write your code here
        boolean used=true;
        int lastTurn=1;
        int []d=new int[direction.size()];
        for(int k=0;k<direction.size();k++) {
        	d[k]=direction.get(k);
        }
       for(int i=0;i<time.size();i++){
    	   if(direction.get(i)>=0)
           for(int j=i+1;j<time.size();j++){
           if(direction.get(j)>=0 ){
               if(time.get(i)==time.get(j)){
                    if(used){
                            if(d[i]!=lastTurn){
                               time.set(i,time.get(i)+1);
                                lastTurn=direction.get(j);
                                direction.set(j,-1);
                                }else{
                               lastTurn=direction.get(i);
                                direction.set(i,-1);
                            }
                   }
                   else{
                            if(direction.get(i)>direction.get(j)){
                             lastTurn=direction.get(i);
                                direction.set(i,-1);
                                time.set(j,time.get(j)+1);
                              }
                            else{
                                lastTurn=direction.get(j);
                                direction.set(j,-1);
                                time.set(time.get(i),time.get(i)+1);
                            }
                    }
                }else{      
                      lastTurn=direction.get(i);
                      direction.set(i,-1);
                     // time.set(j,time.get(j)+1);
                      i++;
                   }
              }
           
              }
        
            }
        return time;
      }    

}


public class Two{
    public static void main(String[] args)  {
        Scanner sc =new Scanner(System.in);

        int timeCount =sc.nextInt();

        List<Integer> time = new ArrayList<>();

        for (int i = 0; i < timeCount; i++) {
            int timeItem = sc.nextInt();
            time.add(timeItem);
        }

        int directionCount = sc.nextInt();

        List<Integer> direction = new ArrayList<>();

        for (int i = 0; i < directionCount; i++) {
            int directionItem = sc.nextInt();
            direction.add(directionItem);
        }

        List<Integer> result = Result.getTimes(time, direction);

        for (int i = 0; i < result.size(); i++) {
           System.out.println(result.get(i));

            if (i != result.size() - 1) {
               System.out.println();
            }
        }

      
    }
}