package Assignment1;

public class Main {
	public static void main(String[] args)
	{
		Thread thread1 = new ThreadDemo();
		Thread thread2 = new ThreadDemo();
		Thread thread3 = new ThreadDemo();
		thread1.start();
		thread2.start();
		thread3.start();
	}
}
