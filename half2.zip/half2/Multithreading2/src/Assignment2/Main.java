package Assignment2;

public class Main {
	public static void main(String[] args)
	{
		for(int i = 0;i<20;i++)
		{
		Thread threadCounter = new Counter();
		Thread threadPrinter = new Printer();
		threadCounter.start();
		try {
			threadCounter.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		threadPrinter.start();
		try {
			threadPrinter.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}
