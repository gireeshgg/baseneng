package Assignment2;

public class Printer extends Thread{
	
	public void run()
	{
		System.out.println(Storage.number);
	}
}
