package Assignment2;

public class Storage {
	public static volatile int number = 0;
}
