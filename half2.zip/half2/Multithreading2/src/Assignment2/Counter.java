package Assignment2;

public class Counter extends Thread{
	public void run()
	{
		Storage.number++;
	}
}
