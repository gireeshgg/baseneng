package Assignment3;
public class Producer extends Data implements Runnable{
	public static int i = 0;
	public void run()
	{
		if(sharedBuffer.size() == 5)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				
			}
			System.out.println("Data hasnt been consumed yet . Please wait .");
		}
		else if(flag == 0)
		{
			flag = 1;
			i++;
			sharedBuffer.add("Data input " + i);
			System.out.println(sharedBuffer + " is being produced .");
		}	
	}
}
