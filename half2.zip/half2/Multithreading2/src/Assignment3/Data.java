package Assignment3;

import java.util.ArrayList;

public class Data {
	public static volatile ArrayList<String> sharedBuffer = new ArrayList<String>();
	public static volatile int flag = 0;
	public static ArrayList<String> getSharedBuffer() {
		return sharedBuffer;
	}
	public static void setSharedBuffer(ArrayList<String> sharedBuffer) {
		Data.sharedBuffer = sharedBuffer;
	}
	public static int getFlag() {
		return flag;
	}
	public static void setFlag(int flag) {
		Data.flag = flag;
	}
}
