package Assignment3;

public class Main {
	public static void main(String[] args)
	{
		for(int i = 0;i<5;i++)
		{
			Thread threadP = new Thread(new Producer());
			Thread threadC = new Thread(new Consumer());
			threadP.start();
			try {
				threadP.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			threadC.start();
			try {
				threadC.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
