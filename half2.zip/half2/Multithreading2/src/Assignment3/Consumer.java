package Assignment3;

public class Consumer extends Data implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(sharedBuffer.size() == 0)
		{
			System.out.println("Data is not produced to be consumed .");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(flag == 1 && sharedBuffer!=null)
		{
			flag = 0;
			System.out.println(sharedBuffer + " is being consumed .");

		}
		
			

	}
	
}
