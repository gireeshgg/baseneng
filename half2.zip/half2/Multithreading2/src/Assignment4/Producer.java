package Assignment4;

public class Producer extends Data implements Runnable{

	public static int ch = 0;
	public static int quantity = 0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		switch(ch)
		{
			case 1 :
				System.out.println("Produced " + quantity + " apples .");
				Producer.sumapples += quantity;
				break;
			case 2 :
				System.out.println("Produced " + quantity + " oranges .");
				Producer.sumoranges += quantity;
				break;
			case 3 :
				System.out.println("Produced " + quantity + " grapes .");
				Producer.sumgrapes += quantity;
				break;
			case 4 :
				System.out.println("Produced " + quantity + " watermelons .");
				Producer.sumwatermelons += quantity;
				break;
		}
	}
	
}
