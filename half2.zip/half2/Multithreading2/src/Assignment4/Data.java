package Assignment4;

import java.util.ArrayList;

public class Data {
	public static volatile ArrayList<Farmer> farmerList = new ArrayList<Farmer>();
	public static volatile Farmer[] farmerMarket = new Farmer[5];
	public static volatile int pointer = 0;
	public static volatile int sumapples = 0;
	public static volatile int sumoranges = 0;
	public static volatile int sumgrapes = 0;
	public static volatile int sumwatermelons = 0;
}
