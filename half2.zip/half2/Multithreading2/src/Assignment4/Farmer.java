package Assignment4;

public class Farmer {
	public int apples = 0;
	public int oranges = 0;
	public int grapes = 0;
	public int watermelons = 0;
	public int getApples() {
		return apples;
	}
	public void setApples(int apples) {
		this.apples = apples;
	}
	public int getOranges() {
		return oranges;
	}
	public void setOranges(int oranges) {
		this.oranges = oranges;
	}
	public int getGrapes() {
		return grapes;
	}
	public void setGrapes(int grapes) {
		this.grapes = grapes;
	}
	public int getWatermelons() {
		return watermelons;
	}
	public void setWatermelons(int watermelons) {
		this.watermelons = watermelons;
	}
	public Farmer(int apples, int oranges, int grapes, int watermelons) {
		super();
		this.apples = apples;
		this.oranges = oranges;
		this.grapes = grapes;
		this.watermelons = watermelons;
	}
}
