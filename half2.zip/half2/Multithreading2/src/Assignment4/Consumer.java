package Assignment4;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
public class Consumer extends Data implements Runnable{
	
	public static int ch = 0;
	public static int quantity = 0;
	
	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		if(ch == 1)
		{
			if((sumapples-quantity)<0)
			{
				try 
				{
					System.out.println("Consumer has to wait .");
					wait();
				}
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else 
			{
				sumapples = sumapples-quantity;
				System.out.println("Consumed " + quantity + " apples .");
			}
		}	
		else if(ch == 2)
		{
			if((sumoranges-quantity)<0)
			{
				try 
				{
					System.out.println("Consumer has to wait .");
					wait();
				}
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else 
			{
				sumoranges = sumoranges-quantity;
				System.out.println("Consumed " + quantity + " oranges .");
			}
		}	
		else if(ch == 3)
		{
			if((sumgrapes-quantity)<0)
			{
				try 
				{
					System.out.println("Consumer has to wait .");
					wait();
				}
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else 
			{
				sumgrapes = sumgrapes-quantity;
				System.out.println("Consumed " + quantity + " grapes .");
			}
		}	
		else if(ch == 4)
		{
			if((sumwatermelons-quantity)<0)
			{
				try 
				{
					System.out.println("Consumer has to wait .");
					wait();
				}
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else 
			{
				sumwatermelons = sumwatermelons-quantity;
				System.out.println("Consumed " + quantity + " watermelons .");
			}
		}	
			
	}

}
