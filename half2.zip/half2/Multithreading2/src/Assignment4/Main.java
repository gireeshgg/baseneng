package Assignment4;
import java.util.Scanner;
public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do
		{
			System.out.println("1. Producer");
			System.out.println("2. Consumer");
			System.out.println("3. Exit");
			Farmer farmer = null;
			choice = sc.nextInt();
			if(choice == 1)
			{
				System.out.println("1. Apples");
				System.out.println("2. Oranges");
				System.out.println("3. Grapes");
				System.out.println("4. Watermelons");
				Producer.ch = sc.nextInt();
				System.out.println("Enter Quantity : ");
				Producer.quantity = sc.nextInt();
				Thread threadP = new Thread(new Producer());
				threadP.start();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(choice == 2)
			{
				System.out.println("1. Apples");
				System.out.println("2. Oranges");
				System.out.println("3. Grapes");
				System.out.println("4. Watermelons");
				Consumer.ch = sc.nextInt();
				System.out.println("Enter Quantity : ");
				Consumer.quantity = sc.nextInt();
				Thread threadC = new Thread(new Consumer());
				threadC.start();
			}
		}while(choice == 1 || choice == 2);
	}
}
