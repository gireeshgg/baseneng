package com.example.springstarterdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStarterDemo11Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringStarterDemo11Application.class, args);
	}
}
