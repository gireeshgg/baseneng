package com.mindtree.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AppController {

	
	
	static String user;
	
	
	
	@RequestMapping("/loginUser")
	public ModelAndView mymethodu( ){
		
		AppController.user="user";
		return new ModelAndView("login","msg",user);
	}
	@RequestMapping("/loginAdmin")
	public ModelAndView mymethoda( ){
		AppController.user="Admin";
		return new ModelAndView("login","msg",user);
	}
	
	
	@RequestMapping(value="/admin")
	public ModelAndView mymethod1(){
	
		return new ModelAndView("admin","msg"," ");
	}
	
	
	@RequestMapping("/register")
	public ModelAndView mymethod2(){
		return new ModelAndView("register","msg","");
	}
	@RequestMapping(value="/registered",method=RequestMethod.POST)
	public ModelAndView mymethod3(){
		return new ModelAndView("register","msg"," Registered  Successfully");
	}
	
	@RequestMapping(value="/user")
	public ModelAndView mymethod(){
	
		return new ModelAndView("user","msg"," ");
	}
	
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public ModelAndView mymethod4(@RequestParam("username") String username,@RequestParam("password") String password ){
		System.out.println("something...");
		if(user.equals("user")) {
			if(username.equals("Gireesh")) {
			if(password.equals("vaachali123")) {
				return new ModelAndView("user","msg","Gireesh");
				}else {
				return new ModelAndView("login","msg","Password Invalid !!!");

				}	
			}else {
				return new ModelAndView("login","msg","Username Invalid !!!");
			}
		}else {
			if(username.equals("Mindtree")) {
				if(password.equals("vaachali123")) {
					return new ModelAndView("admin","msg","Mindtree");
					}else {
					return new ModelAndView("login","msg","Password Invalid !!!");

					}	
				}else {
					return new ModelAndView("login","msg","Username Invalid !!!");
				}
			
		}
	}
}
