package fifth;

import java.util.Scanner;
import java.util.Stack;

public class Stacks {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Stack<Integer> s=new Stack<Integer>();
		
		for(int i=0;i<10;i++) {
			s.push(rand(i));
		}
		for(int i:s) {
			System.out.println(i);
		}
		s.pop();
		System.out.println("after pop:");
		for(int i:s) {
			System.out.println(i);
		}
		System.out.println("Enter Search element");
		int el=sc.nextInt();
		boolean flag=true;
		for(int i:s) {
			if(el==i) {
				System.out.println("found:"+i);
				flag=false;
				break;
			}
		}
		if(flag) {
			System.out.println("Not Found!!");
		}
		
		
		
sc.close();
	}

    static Integer rand(int i) {
		return( i+(i*i)+(i/2));
	}

}
