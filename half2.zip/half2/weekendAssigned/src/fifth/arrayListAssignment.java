package fifth;
import java.util.*;
public class arrayListAssignment {
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<String>al=new ArrayList<String>();
		al.add("How are u doing?");
		al.add("What are you doinng?");
		al.add("are you ok?");
		al.add("Good Maorning!!");
		Iterator it= al.iterator();
		while(it.hasNext()) {
			String str=(String) it.next();
			System.out.println(str);
		}
		System.out.println("Enter location of the element to remove");
		int i=sc.nextInt();
		al.remove(i);
		Iterator irt= al.iterator();
		while(irt.hasNext()) {
			String str=(String) irt.next();
			System.out.println(str);
		}
		System.out.println("Enter location to get the size of String");
		int inx=sc.nextInt();
		int size=al.get(inx).length();
		System.out.println(size);
		Iterator itr= al.iterator();
		while(itr.hasNext()) {
			String str=(String) itr.next();
			if(size==str.length())
			System.out.println(str);
		}
		
	}

}
