package lamdacheck;

import java.util.*;
import java.util.List;

public class Lamda {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("abc", "bhd", "aga");
		list.stream().forEach((s) -> System.out.print(s+s));
		
	} 

}
