package third;
import java.util.*;

public class triplet {
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[]ar=new int[n];
		for(int i=0;i<n;i++) {
		 {
				ar[i]=sc.nextInt();
			}
		}
		printTriplets(ar);
	sc.close();		
	}
	
	public static void printTriplets(int[] data) {		
		
		for(int i=0;i<data.length;i++) {
			for(int j=i+1;j<data.length;j++) {
				for(int k=0;k<data.length;k++) {
					if((data[i]+data[j])==data[k]) {
						System.out.println(data[i]+" + "+data[j]+" = "+data[k]);
						break;
					}
				}
			}
		}
	}
}
