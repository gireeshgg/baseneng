package first;
import java.util.*;
public class ConsStrings {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		s=s.toUpperCase();
		List<String> x=new ArrayList<String>();
		
		for(int i=0;i<s.length();i++){
			int j=i;
			while( j<s.length()-1 && 1+s.charAt(j)==s.charAt(j+1) ){
				j++;	
			}
			while(j>i) {
				x.add(s.substring(i,j+1));
				j--;
			}  
		}
		int [] count=new int[x.size()];
		for(int j=0;j<x.size();j++) {
			
			for(int i=j+1;i<x.size();i++) {
				if(x.get(j).equals(x.get(i))) {
					count[j]++;
					x.remove(i);
				}
			}
			System.out.println(x.get(j)+" "+(count[j]+1));
		}
		System.out.println();
				
		sc.close();
	}
}









