package sixth;

import java.sql.*;
import java.util.*;

public class jdbc1 {

	public static void main(String[] args) {

		Connection con=null;
		PreparedStatement statement=null;
		try {
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc1","root","Welcome123");
			 
			//statement=con.prepareStatement("create table student (rn int,name varchar(20),address varchar(20));");
			statement=con.prepareStatement("insert into student values(?,?,?);");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String[] name= {"Abc","bcd","cde","def","efg"};
		String[] address= {"bengaluru","bengaluru","bengaluru","bengaluru","bengaluru"};
		int [] rn= {1,2,3,4,5};
		for(int i=0;i<5;i++) {
			try {
				statement.setInt(1,rn[i]);
				statement.setString(2,name[i]);
				statement.setString(3,address[i]);

				statement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Statement smt=null;
		try {
			smt = (Statement) con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet res=null;
		try {
			 res = smt.executeQuery("Select * from Student;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		printData(res);
		try {
			res=smt.executeQuery("select * from student where rn=1;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		printData(res);
		try {
			res=smt.executeQuery("update  student set address =\"Bhubneswar\" where rn=3;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		printData(res);
		try {
			res=smt.executeQuery("delete from  student  where rn=3;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		printData(res);

		 try {
			res = smt.executeQuery("Select * from Student;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 printData(res);

		

try {
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
try {
	statement.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
try {
	res.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

	private static void printData(ResultSet res) {
		System.out.println("R.No\tName\tAddress");
		try {
			
			while(res.next()) {
				System.out.println(res.getInt(1)+"\t"+res.getString(2)+"\t"+res.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
