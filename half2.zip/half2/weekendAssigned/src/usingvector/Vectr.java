package usingvector;

import java.util.*;
public class Vectr {

	public static void main(String[] args) {

		
		
				Scanner sc=new Scanner(System.in);
				Vector<String>al=new Vector<String>();
				al.add("How are u doing?");
				al.add("What are you doinng?");
				al.add("are you ok?");
				al.add("Good Maorning!!");
				for(String str:al) {
					System.out.println(str);
				}
				System.out.println("Enter location of the element to remove");
				int i=sc.nextInt()-1;
				al.remove(i);
				for(String str:al) {
					System.out.println(str);
				}
				System.out.println("Enter location to get the size of String");
				int inx=sc.nextInt()-1;
				int size=al.get(inx).length();
				System.out.println(size);
				for(String str:al) {
					if(size==str.length())
					System.out.println(str);
				}
				
	sc.close();		
	}

}
