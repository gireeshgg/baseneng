package com.mindtree.storedprocessjdbc.getAllstudents.services.imp;

import java.sql.ResultSet;

import com.mindtree.storedprocessjdbc.getAllstudents.dao.imp.DbDept;
import com.mindtree.storedprocessjdbc.getAllstudents.services.ServiceImplemetation;

public class DeptService implements ServiceImplemetation {

	
	
	DbDept db=new DbDept();
	@Override
	public void create() throws Exception {
		db.create();
		
	}

	@Override
	public void insert() throws Exception {
		// TODO Auto-generated method stub
		db.insert();
	}

	@Override
	public ResultSet select() throws Exception {
		// TODO Auto-generated method stub
		return db.select();
	}

	@Override
	public void delete() throws Exception {
		// TODO Auto-generated method stub
		db.delete();
	}

	@Override
	public void update() throws Exception {
		// TODO Auto-generated method stub
		db.update();
	}

}
