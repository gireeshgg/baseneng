package com.mindtree.storedprocessjdbc.getAllstudents.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DaoConnect {
	Connection con;
	public Connection connect() {
		try {
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	

}
