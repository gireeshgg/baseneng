package com.mindtree.storedprocessjdbc.getAllstudents.model;


public class Student {
	 int rollnum;
	 String name;
	 String address;
	 int deptId;
	public Student() {
		
	}
	
	public Student(int rollnum, String name, String address, int deptId) {
		this.rollnum = rollnum;
		this.name = name;
		this.address = address;
		this.deptId = deptId;
	}

	public int getRollnum() {
		return rollnum;
	}
	public void setRollnum(int rollnum) {
		this.rollnum = rollnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	
	


	
}
