package com.mindtree.storedprocessjdbc.getAllstudents;


import java.sql.ResultSet;

import com.mindtree.storedprocessjdbc.getAllstudents.services.ServiceImplemetation;
import com.mindtree.storedprocessjdbc.getAllstudents.services.imp.StudentService;

public class App 
{
    public static void main( String[] args )
    {
     ServiceImplemetation student=new StudentService();
    
     
     try {
		student.create();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     try {
		student.insert();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     try {
		ResultSet res=student.select();
		System.out.println("R.No\tName\tAddress \tDeparment");
		while(res.next()) {
			System.out.println(res.getInt(1)+"\t"+res.getString(2)+"\t"+res.getString(3));
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     try {
		student.delete();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
     
    }
}
