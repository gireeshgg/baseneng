package com.mindtree.storedprocessjdbc.getAllstudents.dao;

import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mindtree.storedprocessjdbc.getAllstudents.model.Department;
import com.mindtree.storedprocessjdbc.getAllstudents.model.Student;

public interface DbInterface {
	String[] name= {"Abc","bcd","cde","def","efg"};
	String[] address= {"bengaluru","bengaluru","bengaluru","bengaluru","bengaluru"};
	int [] rn= {1,2,3,4,5};
	int [] deptno= {10,20,30,40,50};
	
	
	List<Student> Slist=new ArrayList<Student>();
	List<Department> Dlist=new ArrayList<Department>();
	void create() throws SQLException  ;
	void insert() throws SQLException;
	ResultSet select() throws SQLException ; 
	void delete() throws SQLException ;
	void update() throws SQLException ;
}
