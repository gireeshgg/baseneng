package com.mindtree.storedprocessjdbc.getAllstudents.dao.imp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mindtree.storedprocessjdbc.getAllstudents.dao.DbInterface;

public class DbDept implements DbInterface {

	Connection con;
	PreparedStatement statement;
	Statement smt;
	
	
	public void insert()throws SQLException {
		
			statement=con.prepareStatement("insert into Department values(?,?,?);"); 
		for(int i=0;i<5;i++) {
			
				statement.setInt(1,rn[i]);
				statement.setString(2,name[i]);
				statement.setString(3,address[i]);
				
				statement.executeUpdate();
		}
		
		
	}

	public ResultSet select() throws SQLException {
		return  smt.executeQuery("Select * from Department;");
		//throw new selectException("Problem in Select Statement");
	}

	public void delete() throws SQLException {
		statement.executeUpdate("delete from  Department  where rn=3;");

	}

	public void update() throws SQLException {
		statement.executeUpdate("update  Department set address =\"Bhubneswar\" where rn=3;");

	}

	public void create() throws SQLException {
		statement=con.prepareStatement("create table Department (rn int,name varchar(20),address varchar(20));");

		
	}

}
