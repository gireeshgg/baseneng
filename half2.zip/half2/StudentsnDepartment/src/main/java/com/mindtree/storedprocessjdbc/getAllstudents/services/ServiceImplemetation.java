package com.mindtree.storedprocessjdbc.getAllstudents.services;

import java.sql.ResultSet;

public interface ServiceImplemetation {
	void create() throws Exception  ;
	void insert() throws Exception;
	ResultSet select() throws Exception ; 
	void delete() throws Exception ;
	void update() throws Exception ;		
}
