package com.mindtree.storedprocessjdbc.getAllstudents.model;


public class Department {
	int deptId;
	String dname;
	String loc;
	public Department() {
		
		// TODO Auto-generated constructor stub
	}
	
	public Department(int deptId, String dname, String loc) {
		this.deptId = deptId;
		this.dname = dname;
		this.loc = loc;
	}

	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	

}
