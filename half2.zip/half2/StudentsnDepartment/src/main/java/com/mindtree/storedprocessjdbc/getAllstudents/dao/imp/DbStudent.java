package com.mindtree.storedprocessjdbc.getAllstudents.dao.imp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mindtree.storedprocessjdbc.getAllstudents.dao.DbInterface;
import com.mindtree.storedprocessjdbc.getAllstudents.exception.InsertException;
import com.mindtree.storedprocessjdbc.getAllstudents.util.DaoConnect;
import com.mysql.jdbc.DatabaseMetaData;


public class DbStudent implements DbInterface {
	Connection con;
	PreparedStatement statement;
	Statement smt;
	ResultSet res;
	DaoConnect dbconnect;

	   

	public DbStudent(){
		dbconnect=new DaoConnect();
		con=dbconnect.connect();
	}

	public void insert()throws SQLException,InsertException {
		
			statement=con.prepareStatement("insert into Student values(?,?,?,?);"); 
		for(int i=0;i<5;i++) {
				statement.setInt(1,rn[i]);
				statement.setString(2,name[i]);
				statement.setString(3,address[i]);
				statement.setInt(4,deptno[i]);
			    statement.executeUpdate();
		}
		
		
	}

	public ResultSet select() throws SQLException {
		smt = (Statement) con.createStatement();
		return res = smt.executeQuery("Select * from Student;");
	}

	public void delete() throws SQLException {
		statement.executeUpdate("delete from  Student  where rn=3;");
		select();
	}

	public void update() throws SQLException {
		statement.executeUpdate("update  Student set address =\"Bhubneswar\" where rn=3;");

	}

	public void create() throws SQLException {
		 DatabaseMetaData meta = (DatabaseMetaData) con.getMetaData();
		  ResultSet res = meta.getTables(null, null, "Student",  new String[] {"TABLE"});
		  if(res.next()) {
			  statement=con.prepareStatement("drop table student; ");
			  statement.executeUpdate();
		  }
		  
		statement=con.prepareStatement("create table Student (rn int,name varchar(20),address varchar(20),deptno varchar(20));");
		statement.executeUpdate();
	}

}
