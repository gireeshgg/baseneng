package com.mindtree;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


//@Controller
@RestController
public class BankService {
	@Autowired
	BankDoa bd;
	
	@GetMapping("/bank")
	public String index()
	{
		return "bank.html";
	}
	
	//@ResponseBody
	@PostMapping(value="/addbank",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public String addBank(@RequestBody Bank bank)
	{
		System.out.println(bank);
		return bd.addBankDetails(bank);
	}
	
	//@ResponseBody
	@GetMapping(value ="/getid/{bankcode}", produces = {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public Optional<Bank> getId(@PathVariable int bankcode)
	{
		System.out.println(bankcode);
		Optional<Bank> b = bd.getById(bankcode);
		return b;
	}

	
	//@ResponseBody
	@GetMapping(value ="/getBank", produces = {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public List<Bank> getBank(){
		try {
		return bd.getAllBankDetails();
		}catch(Exception e)
		{
		}
		return null;
	}

	//@ResponseBody
	@PutMapping(value="/updateBank",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public String updateBank(@RequestBody Bank bank) {
		System.out.println(bank);
		return bd.updateBank(bank);
	}

	//@ResponseBody
	@DeleteMapping(value ="/deletes/{bankcode}", produces = {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public String deleteBank(@PathVariable int bankcode) {
		System.out.println(bankcode);
		return bd.deleteBankById(bankcode);
	}

}
