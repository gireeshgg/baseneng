package com.mindtree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class BankWithValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankWithValidationApplication.class, args);
	}
}
