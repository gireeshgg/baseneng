package com.mindtree;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bank {
	@Id
	private int bankcode;
	private String name;
	private String ifsc;
	private String branch;
	private String address;
	
	@Override
	public String toString() {
		return "\n [bankcode=" + bankcode + ", name=" + name + ", ifsc=" + ifsc + ", branch=" + branch + ", address="
				+ address + "]";
	}
	public Bank() {
		super();
	}
	public int getBankcode() {
		return bankcode;
	}
	public void setBankcode(int bankcode) {
		this.bankcode = bankcode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
