package com.mindtree.jdbcTemplate;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


public class Dao {
	 /*String dbUrl="jdbc:mysql://localhost:3306/jdbcspring";
	 String dbUsername="root";
	 String dbPassword="Welcome123";
	private DataSource dataSource = new DriverManagerDataSource(dbUrl, dbUsername, dbPassword);
*/
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	public String insert()
	{
		String sql = "insert into employee values(51,'sam')";
		jdbcTemplate.update(sql);
		return "Added sucessfully";
	}
	public String getEmployeeById(int id)
	{
		String sql = "SELECT name FROM employee WHERE id = ?";
		String name = jdbcTemplate.queryForObject(sql, new Object[] {id},String.class);
		return name;
	}
	public String delete(int id)
	{
		String sql = "delete from employee WHERE id = 51";
		
		return "Deleted Successfully";
	}

}
