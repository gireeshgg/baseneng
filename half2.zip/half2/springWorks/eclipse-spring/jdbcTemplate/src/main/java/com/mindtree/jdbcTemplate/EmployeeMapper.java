package com.mindtree.jdbcTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeMapper implements RowMapper<employee> {

	public employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		employee e =new employee();
		e.setId(rs.getInt("id"));
		e.setName(rs.getString("name"));
		
		return e;
	}

}
