package com.mindtree.jdbcTemplate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        /*System.out.println( "Hello World!" );
        Dao d = new Dao();
        //d.insert();
       //System.out.println(d.countofemp());
        //System.out.println(d.getEmployeeById(1));
        System.out.println("Inserted");*/
    	
    	
    	 ApplicationContext ctx=new ClassPathXmlApplicationContext("ApplicationContext.xml");  
         
    	 Dao dao=(Dao)ctx.getBean("edao");  
    	 //System.out.println(dao.insert());
        //System.out.println(dao.getEmployeeById(5));
    	 //System.out.println(dao.delete(51));
    }
}
