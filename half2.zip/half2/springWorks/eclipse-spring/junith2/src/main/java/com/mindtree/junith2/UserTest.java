package com.mindtree.junith2;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

public class UserTest {
	
	private EmbeddedDatabase db;
	
	 @Before
	    public void setUp() {
	    	db = new EmbeddedDatabaseBuilder()
	    		.setType(EmbeddedDatabaseType.H2)
	    		.addScript("db/sql/create-db.sql")
	    		.addScript("db/sql/insert-data.sql")
	    		.build();
	    }
	 
	 @Test
	    public void testFindByname() {
	    	
	    	User user = new User();
	    	user.setId(1);
	    	user.setName("sri");
	    	user.setEmail("srini");
	  
	    	Assert.assertNotNull(user);
	    	Assert.assertEquals(1, user.getId());
	    	Assert.assertEquals("sri", user.getName());
	    	Assert.assertEquals("srini", user.getEmail());

	    }

	    @After
	    public void tearDown() {
	        db.shutdown();
	    }

}
