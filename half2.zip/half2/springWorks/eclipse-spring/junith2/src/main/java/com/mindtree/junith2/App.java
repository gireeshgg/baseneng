package com.mindtree.junith2;

public class App 
{
    public static void main( String[] args )
    {
    	
    }
}
