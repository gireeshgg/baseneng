package com.mindtree.getNsetBeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
        A one = (A) context.getBean("aclass");
        one.setMsg2("sam");
        
        B two = (B) context.getBean("bclass");
        System.out.println(two.getMsg2());
    	
    }
}
