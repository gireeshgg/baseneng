package com.mindtree;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.entity.User;

@Controller
public class ContollerClass {
	
	@RequestMapping("/hello")
	public ModelAndView helloWorld() {
		String msg="Thanks Prakash";
		return new ModelAndView("hellopage","message",msg);
	}
	
	@RequestMapping("/validate")
	public ModelAndView helloWorld1() {
		String msg="Thanks Prakash";
		return new ModelAndView("validate1","message",msg);
	}
	
	@RequestMapping(value="/validate1",method=RequestMethod.POST)
	public void validate(@Validated User user,Model model) {
		System.out.println("HIIIII");
		System.out.println(user);
		String msg = user.getUsername(); 
	}
}
