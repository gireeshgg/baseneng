package com.mindtree;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class Calci {
	@WebMethod
	public int add(int p1,int p2)
	{
		return p1+p2;
	}
	@WebMethod
	public int sub(int p1,int p2)
	{
		return p1-p2;
	}
}
