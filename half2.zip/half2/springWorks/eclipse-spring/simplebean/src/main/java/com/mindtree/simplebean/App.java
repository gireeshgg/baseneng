package com.mindtree.simplebean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	
    	//simple
    	/*Triangle t = new Triangle();
    	trainagle.draw();*/
    	
    	//using bean
    	BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\M1049037\\eclipse-spring\\simplebean\\src\\main\\java\\com\\mindtree\\simplebean\\spring.xml"));
    	Triangle t = (Triangle) factory.getBean("triangle");
    	t.draw("1st one");
    	
    	Triangle t2 = (Triangle) factory.getBean("triangle");
    	System.out.println(t2.output());
    	
    	/*//Application Context
    	ApplicationContext context = new ClassPathXmlApplicationContext("C:\\Users\\M1049037\\eclipse-spring\\simplebean\\src\\main\\java\\spring.xml");
    	Triangle t1 = (Triangle) context.getBean("triangle");
    	t1.draw();*/
    	
    	
    }
}
