package com.mindtree.simplebean;

public class Triangle {
	String a;
	public void draw(String a)
	{
		System.out.println("Traingle Draw");
		this.a=a;
	}
	public String output()
	{
		return a;
	}
}
