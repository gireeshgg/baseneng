package com.mindtree.simplecontext;

import org.springframework.beans.factory.InitializingBean;

public class Triangle implements InitializingBean {
	String a = null;
	public void draw(String a)
	{
		System.out.println("Traingle Draw");
		this.a=a;
	}
	public String output()
	{
		return a;
	}
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		
	}
	public void init()
	{
		System.out.println("Created bean");
	}
	public void destroy()
	{
		System.out.println("Destroyed bean");
	}
}
