package com.mindtree.simplecontext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	//scope=prototype
    	//scope=singleton
    	ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
    	Triangle t1 = (Triangle) context.getBean("triangle");
    	t1.draw("one");
    	Triangle t2 = (Triangle) context.getBean("triangle");
    	System.out.println(t2.output());
    	((AbstractApplicationContext) context).registerShutdownHook();
    	
    }
}
