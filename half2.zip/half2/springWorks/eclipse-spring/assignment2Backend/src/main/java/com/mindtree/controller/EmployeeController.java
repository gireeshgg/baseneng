package com.mindtree.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.doa.EmployeeDoaImple;
import com.mindtree.entity.Employee;


@RestController
public class EmployeeController {
	
	private EmployeeDoaImple employeeDoa;
	
	@RequestMapping(method=RequestMethod.POST,value="/EmployeeMgt/addEmployee")
	public void addTopic(@RequestBody Employee e) {
		System.out.println(e);
		employeeDoa.addEmployee(e);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/EmployeeMgt/deleteEmployee/{empId}")
	public void deleteEmployee(@PathVariable int empId)
	{
		System.out.println(empId);
		employeeDoa.deleteEmployee(empId);
	}
	
	@RequestMapping("/EmployeeMgt/getAllEmployees")
	public List<Employee> getAllTopics() {
		System.out.println("Call Happended");
		return employeeDoa.allEmployees();
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/EmployeeMgt/updateEmployee")
	public void updateDetails(@RequestBody Employee e)
	{
		System.out.println(e);
		employeeDoa.updateEmployee(e);
	}
	
	@RequestMapping("/EmployeeMgt/getEmployeeById/{empId}")
	public Employee getById(@PathVariable int empId)
	{
		System.out.println(empId);
		return employeeDoa.getById(empId);
	}
	
	@RequestMapping("/EmployeeMgt")
	public void employeeMgt()
	{
		System.out.println("Running");
		
	}
	
	public String ValidEmployee(@PathVariable String username,@PathVariable String password)
	{
		System.out.println(username+password);
		return employeeDoa.validEmployee(username,password);
	}

}
