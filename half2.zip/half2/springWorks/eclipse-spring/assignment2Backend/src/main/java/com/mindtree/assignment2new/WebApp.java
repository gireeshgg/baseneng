package com.mindtree.assignment2new;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.mindtree.controller")
public class WebApp {

	public static void main(String[] args) {
	}

}
