package mindtree.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDatabase {
	private static String user ="root";
	private static String password ="Welcome123";
	private static String url = "jdbc:mysql://localhost:3306/bankapp";
	public  Connection connectDb() 
	{
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Successfull");
			return conn;
		}
		catch (SQLException e) {
			
		}
		return null;
	}
	
	/*public static void main(String[] args)
	{
		Connection conn = connectDb();
		try {
			Statement s = conn.createStatement();
			
			ResultSet rs = s.executeQuery("select * from bank");
			while(rs.next())
				System.out.println(rs.getInt(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
}
