package mindtree.com;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class BankDoa {
	
	public Bank getById(int bankcode)  {
		
		try {
			ConnectionDatabase cd = new ConnectionDatabase();
			Connection conn = cd.connectDb();
			String query = "select * from bank where bankcode = ?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1,bankcode);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Bank bank = new Bank();
				bank.setBankcode(bankcode);
				bank.setName(rs.getString(2));
				bank.setIfsc(rs.getString(3));
				bank.setBranch(rs.getString(4));
				bank.setAddress(rs.getString(5));
				return bank;
			}
			
			conn.close();
			ps.close();
		}
		catch(Exception e)
		{
		}
		return null;
	}

	public List<Bank> getAllBankDetails()  {
		List<Bank> b = new ArrayList<Bank>();
		try {
			ConnectionDatabase cd = new ConnectionDatabase();
			Connection conn = cd.connectDb();
			String query = "select * from bank";
			
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Bank bank = new Bank();
				bank.setBankcode(rs.getInt(1));
				bank.setName(rs.getString(2));
				bank.setIfsc(rs.getString(3));
				bank.setBranch(rs.getString(4));
				bank.setAddress(rs.getString(5));
				b.add(bank);
			}
			
			conn.close();
			ps.close();

			return b;
		}
		catch(SQLException e)
		{
		}
		return  null;
		
	}

	public String updateBank(Bank bank)  {
		int flag=0;
		try {
			
			ConnectionDatabase cd = new ConnectionDatabase();
			Connection conn = cd.connectDb();
			String query = "update bank set bankcode = ?,name = ? ,ifsc = ? ,branch = ? ,"
					+ "address = ? " + 
					"where bankcode =?;";
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1,bank.getBankcode());
			ps.setString(2, bank.getName());
			ps.setString(3, bank.getIfsc());
			ps.setString(4, bank.getBranch());
			ps.setString(5, bank.getAddress());
			ps.setInt(6, bank.getBankcode());
			flag = ps.executeUpdate();
			
			conn.close();
			ps.close();
			
		} catch (SQLException e) {

		}
		if(flag!=0)
			return "sucess";
		return "failure";
	}

	public String deleteBankById(int bankCode) {
		try
		{
			ConnectionDatabase cd1 = new ConnectionDatabase();
			Connection conn1 = cd1.connectDb();
			String query1 = "delete from bank where bankcode = ?";
			PreparedStatement ps1 = conn1.prepareStatement(query1);
			ps1.setInt(1, bankCode);
			ps1.executeUpdate();
			
			conn1.close();
			ps1.close();
			return "success";
		}
		catch(Exception e)
		{
		}
		return "Failure";
	}

	public String addBankDetails(Bank bank) {
		int flag=0;
		try {
			ConnectionDatabase cd = new ConnectionDatabase();
			Connection conn = cd.connectDb();
			String query = "insert into bank values(?,?,?,?,?)";
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1,bank.getBankcode());
			ps.setString(2, bank.getName());
			ps.setString(3, bank.getIfsc());
			ps.setString(4, bank.getBranch());
			ps.setString(5, bank.getAddress());
			flag = ps.executeUpdate();
			
			conn.close();
			ps.close();
			
		} catch (SQLException e) {

		}
		if(flag!=0)
			return "sucess";
		return "failure";
	}
	
}
