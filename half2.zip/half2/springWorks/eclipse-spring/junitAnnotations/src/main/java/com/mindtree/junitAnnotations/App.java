package com.mindtree.junitAnnotations;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class App 
{
   
    	static int beforecount=0;
    	static int aftercount=0;
    	static int beforeclasscount=0;
    	static int afterclasscount=0;
    	static int testcount=0;
    	
    	@BeforeClass
    	public static void beforeclass()
    	{
    		System.out.println("Before Class "+(++beforeclasscount));
    	}
    	@Before
    	public void before()
    	{
    		System.out.println("Before "+(++beforecount));
    	}
    	@Test
    	public void test1()
    	{
    		System.out.println("Test case 1:"+(++testcount));
    	}
    	@Test
    	public void test2()
    	{
    		System.out.println("Test case 2:"+(++testcount));
    	}
    	@Test
    	public void test3()
    	{
    		System.out.println("Test case 3:"+(++testcount));
    	}
    	@Test
    	public void test4()
    	{
    		System.out.println("Test case 4:"+(++testcount));
    	}
    	@Test
    	public void test5()
    	{
    		System.out.println("Test case 5:"+(++testcount));
    	}
    	@AfterClass
    	public static void  afterclass()
    	{
    		System.out.println("After class "+(++afterclasscount));
    	}
    	@After
    	public void after()
    	{
    		System.out.println("After "+(++aftercount));
    	}
    
}
