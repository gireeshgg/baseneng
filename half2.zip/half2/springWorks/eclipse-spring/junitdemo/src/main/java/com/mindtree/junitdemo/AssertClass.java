package com.mindtree.junitdemo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class AssertClass {
	int num;
	String temp,str;
	
	@Before
	public void setup()
	{
		num=5;
		temp=null;
		str="String set";
	}
	
	@Test
	public void test()
	{
		assertEquals("String set",str);
		
		assertFalse(num>6);
		
		assertNotNull(str);
		
		assertNull(temp);
		
		//assertNull(str);
		
		assertTrue(num ==5);
	}
	

}
