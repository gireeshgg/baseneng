package com.mindtree.mockito;
import org.junit.runner.RunWith;

//@RunWith(MockitoJUnitRunner.class)
public class MathApplicationTester {
	
	   MathApplication mathApplication ;
}
