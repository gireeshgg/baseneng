package com.mindtree.doa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.mindtree.entity.User;



public class UserDoaImple {
	
		HibernateTemplate template = new HibernateTemplate();
		public HibernateTemplate getTemplate() {
			return template;
		}

		public void setTemplate(HibernateTemplate template) {
			this.template = template;
		}

		//Add User
		public void addUser(User user)
		{
			Session s = template.getSessionFactory().openSession();
			s.save(user);
			s.beginTransaction().commit();
			System.out.println("Success");
		}
		
		//view all users
		public List<User> allUsers()
		{
			return template.loadAll(User.class);
		}
		
		//view by empid
		public User getByEmpId(int id)
		{
			return template.get(User.class, id);
		}
		
	

}
