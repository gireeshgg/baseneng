package com.mindtree.doa;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.mindtree.entity.Project;
import com.mindtree.entity.User;



public class ProjectDoaImple {
	
		HibernateTemplate template = new HibernateTemplate();
		public HibernateTemplate getTemplate() {
			return template;
		}

		public void setTemplate(HibernateTemplate template) {
			this.template = template;
		}

		//Add Project
		public void addProject(Project project)
		{
			Session s = template.getSessionFactory().openSession();
			s.save(project);
			s.beginTransaction().commit();
			System.out.println("Success");
		}
		
		//view all projects
		public List<Project> allProjects()
		{
			return template.loadAll(Project.class);
		}
		
		
		//view team members
		public List<User> teamMembers(int pid)
		{
			return (new UserDoaImple()).allUsers().stream().filter(e -> e.getProjectId()==pid).collect(Collectors.toList());
		}
	

}
