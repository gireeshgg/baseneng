package com.mindtree;
import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.entity.Employee;
import com.mindtree.entity.User;

@Controller
public class ContollerClass {
	
	@RequestMapping("/hello")
	public ModelAndView helloWorld() {
		String msg="Thanks Prakash";
		return new ModelAndView("hellopage","message",msg);
	}
	@RequestMapping("/srini")
	public ModelAndView srini1() {
		String msg="Hey Srini";
		return new ModelAndView("srini","email",msg);
	}
	
	@RequestMapping("/addEmp")
	public ModelAndView addEmp() {
		String msg="Welcome";
		return new ModelAndView("addEmp","message",msg);
	}
	
	
	
	@RequestMapping("/login")
	public ModelAndView login() {
		String msg = "Welcome";
		return new ModelAndView("login123","message",msg);
	}
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public ModelAndView validate(@Validated User user,Model model) {
		
		System.out.println(user);
		if(user.getUsername().compareTo("srini")==0&&user.getPassword().compareTo("srini")==0)
		{
			String msg="";
			return new ModelAndView("addEmp","message",msg); 
		}
		else
		{
			String msg = "Wrong Input";
			return new ModelAndView("login123","message",msg);
		}
	} 
	@RequestMapping(value="/addEmp",method=RequestMethod.POST)
	public ModelAndView afterAddEmp(@Validated Employee emp,Model model) {
		System.out.println("hiiiiiiii");
		System.out.println(emp);
		String msg = "Next Step";
		return new ModelAndView("srini","email",msg);
	}
	
	
}
