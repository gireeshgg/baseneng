package com.mindtree.beanentity;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigurationClass {
	public Employee display()
	{
		return new Employee();
	}

}
