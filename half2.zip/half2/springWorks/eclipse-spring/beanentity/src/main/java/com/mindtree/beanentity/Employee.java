package com.mindtree.beanentity;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

public class Employee {
	private int id;
	private String name;
	private int age;
	
	public Employee(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
	public Employee() {
		super();
	}
	@Bean
	public int getId() {
		return id;
	}
	@Bean
	public void setId(int id) {
		this.id = id;
	}
	@Bean
	public String getName() {
		return name;
	}
	@Bean
	public void setName(String name) {
		this.name = name;
	}
	@Bean
	public int getAge() {
		return age;
	}
	@Bean
	public void setAge(int age) {
		this.age = age;
	}
	@Bean
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + "]\n";
	}
}
