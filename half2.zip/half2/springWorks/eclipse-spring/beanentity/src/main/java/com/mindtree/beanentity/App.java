package com.mindtree.beanentity;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	ApplicationContext ac = new AnnotationConfigApplicationContext(ConfigurationClass.class);
    	ConfigurationClass cc = ac.getBean(ConfigurationClass.class);
    	Employee e = cc.display();
    	System.out.println("Working Fine");
    	
    }
}

