package com.mindtree.mockito2;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

public class TestCalculator  {
	Calculator c = null;
	
	//CalculatorService service = Mockito.mock(CalculatorService.class);
	@Mock
	CalculatorService service;
	@Rule public MockitoRule rule = MockitoJUnit.rule();
	
	
	@Before
	public void before()
	{
		c = new Calculator(service);
	}
	
	@Test
	public void testAdd()
	{
		//Implement service
		when(service.add(2, 3)).thenReturn(5);
		//Checking test case
		assertEquals(10,c.perform(2, 3));
		//to check mock service is called or not
		verify(service).add(2, 3);
	}
}
