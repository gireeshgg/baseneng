package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TopicService {
		@Autowired
		private  EmployeeRepository ep;
		TopicService()
		{
			
		}
		public List<Employee> getAllTopics() {
			List<Employee> l = new ArrayList<Employee>();
			ep.findAll().forEach(e-> {l.add(e);});
			return l;
		}
		public void addEmployee(Employee e)
		{
			ep.save(e);
		}
		public void updateEmployee(Employee e)
		{
			ep.save(e);
		}
		public void deleteEmployee(int id)
		{
			ep.deleteById(id);
		}
}
