package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class TopicService {
	
		Employee[] e = new Employee[3];
		static int j=0;
		List<Employee> l = new ArrayList<Employee>();
		TopicService()
		{
			
		}
		public List<Employee> getAllTopics() {
			if(j==0)
				for(int i=0;i<3;i++)
				{
					e[i] = new Employee(i,"sam"+i,i+21);
					l.add(e[i]);
					j=1;
				}
			return l;
		}
		public void addEmployee(Employee e)
		{
			l.add(e);
		}
		public void updateEmployee(Employee e)
		{
			l.stream().filter(e1 -> e1.getId()==e.getId()).forEach(e1 -> {e1=e; });
		}
		public void deleteEmployee(int id)
		{
			l.removeIf(t -> t.getId()==id);
		}
		
	
}
