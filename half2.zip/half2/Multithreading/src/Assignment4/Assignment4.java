package Assignment4;

public class Assignment4 implements Runnable{
	
	public static volatile int flag = 0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(flag==1)
		{
			showSeats();
			flag = 0;
		}
		else if(flag==0)
		{
			printTicket();
			flag = 1;
		}
		
	}
	public void printTicket()
	{
		System.out.println("Thread : " + Thread.currentThread().getName());
		System.out.println("Print your Ticket .");
		
	}
	public void showSeats()
	{
		System.out.println("Thread : " + Thread.currentThread().getName());
		System.out.println("Showing to your seats .");
	}
}
