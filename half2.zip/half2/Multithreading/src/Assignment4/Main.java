package Assignment4;

public class Main {
	public static void main(String[] args)
	{
		Thread threadA = new Thread(new Assignment4());
		Thread threadB = new Thread(new Assignment4());
		threadA.start();
		try {
			threadA.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		threadB.start();
		try {
			threadB.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Completed!");
	}
}
