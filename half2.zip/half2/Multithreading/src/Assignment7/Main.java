package Assignment7;
import java.util.Scanner;
public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of x : ");
		int x = sc.nextInt();
		System.out.println("Enter the value of y : ");
		int y = sc.nextInt();
		Assignment7.y = y;
		Thread[] thread = new Assignment7[x];
		for(int i = 0;i<x;i++)
		{
			thread[i] = new Assignment7();
			thread[i].start();
		}
		try {
			thread[x-1].join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Assignment7.count);
	}
}
