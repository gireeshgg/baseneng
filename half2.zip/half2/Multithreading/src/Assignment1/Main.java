package Assignment1;

public class Main {

	public static void main(String[] args)
	{
		Assignment1 threadA = new Assignment1();
		Assignment1 threadB = new Assignment1();
		threadA.start();
		threadB.start();
	}
}
