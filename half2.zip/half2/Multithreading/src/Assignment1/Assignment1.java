package Assignment1;

public class Assignment1 extends Thread{
	public static volatile int count = 1;
	public void run()
	{
		for(int i = 0;i<5;i++)
		{
			display();
		}
		
	}
	public static synchronized void display()
	{
		System.out.println(count++);
		System.out.println("Thread :" + Thread.currentThread().getName());
	}
}
