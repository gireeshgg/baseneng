package Assignment2;

public class Main {
	public static void main(String[] args)
	{
		Thread threadC = new Thread(new Assignment2());
		Thread threadD = new Thread(new Assignment2());
		threadC.start();
		threadD.start();
	}
}
