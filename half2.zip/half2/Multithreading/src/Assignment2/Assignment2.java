package Assignment2;

public class Assignment2 implements Runnable{

	public static volatile int count = 1;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(count<25)
		{
			display();
		}
	}
	public static synchronized void display()
	{
		System.out.println(count++);
	}
}
