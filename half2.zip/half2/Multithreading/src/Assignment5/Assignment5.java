package Assignment5;

public class Assignment5 implements Runnable{
	public static volatile int seatflag = 0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(seatflag == 0)
		{
			seatflag = 1;
			System.out.println("Seat Allocated to Thread : " + Thread.currentThread().getName());
		}
	}
	 
}
