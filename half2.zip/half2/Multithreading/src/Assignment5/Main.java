package Assignment5;
import java .util.Scanner;
public class Main {
	public static void main(String[] args)
	{
		Thread thread1 = new Thread(new Assignment5());
		Thread thread2 = new Thread(new Assignment5());
		thread1.start();
		thread2.start();
	}
}
