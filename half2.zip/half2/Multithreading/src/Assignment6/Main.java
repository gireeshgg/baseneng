package Assignment6;

import Assignment5.Assignment5;

public class Main {
	public static void main(String[] args)
	{
		Thread thread1 = new Thread(new Assignment6());
		Thread thread2 = new Thread(new Assignment6());
		thread1.start();
		thread2.start();
	}
}
