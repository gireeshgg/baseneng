package Assignment6;

public class Assignment6 implements Runnable{
	public static volatile int seatflag = 0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		assignSeat();
		
	}
	public static synchronized void assignSeat()
	{
			if(seatflag == 0)
			{
				seatflag = 1;
				System.out.println("Seat Allocated to Thread : " + Thread.currentThread().getName());
			}
			else if(seatflag == 1)
			{
				seatflag = 1;
				System.out.println("Seat Cannot be Allocated to Thread : " + Thread.currentThread().getName());
			}
	}
}
