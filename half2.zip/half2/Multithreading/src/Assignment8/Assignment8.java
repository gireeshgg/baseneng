package Assignment8;

import Assignment7.Assignment7;

public class Assignment8 extends Thread{
	public static volatile int count  = 0;
	public static volatile int y = 0;
	
	public static int getY() {
		return y;
	}
	public static void setY(int y) {
		Assignment7.y = y;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
			increment();
		
	}
	public static synchronized void increment()
	{
		for(int i = 0;i<y;i++)
		{
			
			count++;
		}
	}
}
