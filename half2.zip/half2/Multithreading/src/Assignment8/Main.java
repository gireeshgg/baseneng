package Assignment8;

import java.util.Scanner;

import Assignment7.Assignment7;

public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of x : ");
		int x = sc.nextInt();
		System.out.println("Enter the value of y : ");
		int y = sc.nextInt();
		Assignment8.y = y;
		Thread[] thread = new Assignment8[x];
		for(int i = 0;i<x;i++)
		{
			thread[i] = new Assignment8();
			thread[i].start();
			try {
				thread[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			thread[x-1].join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Assignment8.count);
	}
}
