package Assignment3;

public class Assignment3 implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Hi . I am Thread : " + Thread.currentThread().getName());
		System.out.println("Task 1");
		task2();
	}
	public void task2()
	{
		System.out.println("Hello . I am Thread : " + Thread.currentThread().getName());
		System.out.println("Task 2");
		task3();
	}
	public void task3()
	{
		System.out.println("Still Thread : " + Thread.currentThread().getName());
		System.out.println("Task 3 . \n Completed .");
	}
}
