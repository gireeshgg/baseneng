package mypackages;



public class GG {
	public String Substring(int i,int j,String str) {         // Substring function
		String res=new String();
		for(int x=i;x<j;x++) {
			res=res+str.charAt(x);
		}
		return res;
	}
	
  public boolean Equal(String str,String str1) {             //equal function
		boolean flag=true;
		for(int x=0;x<str.length();x++) {
			if(str.charAt(x)!=str1.charAt(x)) {
				flag=false;
				break;
			}
		}
		return flag;
	}

}
